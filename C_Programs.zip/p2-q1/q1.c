/*
 * q1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

void input(int r,int c,int (*a)[c]);
void print(int r,int c,int (*a)[c]);
void sort(int r,int c,int (*a)[c]);

int main()
{
	int r=2,c=2,a[r][c];
	setvbuf(stdout, NULL, _IONBF, 0);
	input(r,c,a);
	print(r,c,a);
	sort(r,c,a);
	print(r,c,a);
	return 0;
}

void input(int r,int c,int (*a)[c])
{
	int i,j;
	printf("enter elements:");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			scanf("%d",*(a+i)+j);
		}
	}
}

void print(int r,int c,int (*a)[c])
{
	int i,j;
		printf("\nelements:\n");
		for(i=0;i<r;i++){
			for(j=0;j<c;j++){
				printf("%d\t",*(*(a+i)+j));
			}
			printf("\n");
		}
}

void sort(int r,int c,int (*a)[c])
{
	int i,j,temp;
	int d[r*c];
	int k=0;
	for(int i=0;i<r;i++){
		for(int j=i+1;j<c;j++){
			d[k]=(*(a+i)+j);
			k++;
		}
	}

    for(i=0;i<k;i++){
    	for(j=i+1;j<k;j++){
    		if(d[i]>d[j]){
    			temp=d[i];
    			d[i]=d[j];
    			d[j]=temp;
    		}
    	}
    }

    k=0;
    for(int i=0;i<r;i++){
    		for(int j=i+1;j<c;j++){
    			(*(a+i)+j)=d[k];
    			k++;
    		}
    	}

    printf("\nelements:\n");
    		for(i=0;i<r;i++){
    			for(j=0;j<c;j++){
    				printf("%d\t",*(*(a+i)+j));
    			}
    			printf("\n");
    		}
}
