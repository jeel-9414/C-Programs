/*

 * q12.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul

#include<stdio.h>
int len(char*);
void reverse(char*);
int main() {
	char a[50], *p;
	p = a;

	printf("enter string here:");
	scanf("%s", a);

	reverse(p);

	printf("\n%s", a);
	return 0;
}
int len(char *a) {
	int i = 0;

	while (*(a + i) != '\0') {
		i++;
	}

	return i;
}
void reverse(char *a) {
	int l1 = len(a);
	int i;
	char temp;

	for (i = 0; i < l1; i++) {
		for (int j = l1 -i- 1; j > i; j--) {
			temp = *(a + i);
			*(a + i) = *(a + j);
			*(a + j) = temp;
		}
	}

}
*/
#include <stdio.h>
#include <string.h>

void reverse(char str[]);

int main() {
    char str[100];
    printf("Enter a string: ");
    scanf("%s", str);

    reverse(str);
    printf("Reversed string: %s\n", str);

    return 0;
}

void reverse(char str[]) {
    int len = strlen(str); // Get the length of the string
    char temp; // Temporary variable for swapping

    for (int i = 0; i < len; i++) { // Outer loop iterates through the string
        for (int j = len -i- 1; j > i; j--) { // Inner loop starts from the end
            temp = str[i];
            str[i] = str[j];
            str[j] = temp;

            break;
        }
    }

}
