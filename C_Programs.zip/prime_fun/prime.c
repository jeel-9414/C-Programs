/*
 * prime.c
 *
 *  Created on: 10 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int prime(int);

int main(){
	int n;
	printf("enter number here:");
	scanf("%d",&n);

	if(prime(n)==0){
		printf("Prime number\n");
	}else{
		printf("not prime number\n");
	}
	//printf("The number is prime(1) or not if(0):%d\n",prime(n));
	return 0;
}

int prime(int n){
	int i,count=0;
	for(i=2;i<=n;i++){
		if(n%i==0){
			count++;
		}
	}

	if(count==2){
		return 1;
	}else{
		return 0;
	}
}
