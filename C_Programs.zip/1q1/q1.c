/*
 * q1.c
 *
 *  Created on: 26 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#define N 50
#define pf printf
#include<string.h>
typedef struct {
	char name[50];
	int pop;
	float lvl;
} census;

int main() {
	census c1[N];
	int n, i;

	printf("enter n:");
	scanf("%d",&n);

	for (i = 0; i < n; i++) {
		scanf("%s %d %f", c1[i].name,&c1[i].pop,&c1[i].lvl);
	}

	census temp;

	for (i = 0; i < n; i++) {
		for (int j = i + 1; j < n; j++) {
			if (strcmp(c1[i].name, c1[j].name) > 0) {
				temp = c1[i];
				c1[i] = c1[j];
				c1[j] = temp;
			}
		}
	}

	pf("name\n");
	for (i = 0; i < n; i++) {
		pf("%s %d %f\n", c1[i].name, c1[i].pop, c1[i].lvl);
	}

	for (i = 0; i < n; i++) {
		for (int j = i + 1; j < n; j++) {
			if (c1[i].lvl > c1[j].lvl) {
				temp = c1[i];
				c1[i] = c1[j];
				c1[j] = temp;

			}
		}
	}

	pf("lvl\n");
	for (i = 0; i < n; i++) {
			pf("%s %d %f", c1[i].name, c1[i].pop, c1[i].lvl);
		}

	for (i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				if (c1[i].pop > c1[j].pop) {
					temp = c1[i];
					c1[i] = c1[j];
					c1[j] = temp;

				}
			}
		}

	pf("pop\n");
	for (i = 0; i < n; i++) {
			pf("%s %d %f", c1[i].name, c1[i].pop, c1[i].lvl);
		}
	return 0;
}
