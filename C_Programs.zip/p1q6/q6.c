/*
 * q6.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
int sum(int ,int );
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	int a,b;
	printf("enter a and b here:");
	scanf("%d %d",&a,&b);

	printf("sum is=%d",sum(a,b));
	return 0;
}

int sum(int a,int b){
	return a+b;
}
