/*
 * fact.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */

#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("error");
	}
	else{
		int a;
		a=atoi(argv[1]);
		int fact=1;
		int i;
		for(i=1;i<=a;i++){
			fact=fact*i;
		}

		printf("factorial is=%d",fact);
	}
}


