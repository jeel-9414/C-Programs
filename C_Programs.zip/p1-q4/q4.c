/*
 * q2.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct {
	int aid;
	char title[50];
	char aname[50];
	int price;
	int flag;
} book;

void input();
void print();
void sort();
int count();
void author();
void books();
int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	int ch, choice;


	printf("\n1.Input\n");
	printf("2.Display\n");
	printf("3.by author\n");
	printf("4.by Title\n");
	printf("5.total Books\n");
	printf("6.Sort by Accession number\n");
	printf("7.Exit\n");

	do {

		printf("enter Choice here(1-7):");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			input();
			break;

		case 2:
			print();
			break;

		case 3:
			author();
			break;

		case 4:
			books();
			break;

		case 5:
			printf("Total Books:%d\n", count());
			break;

		case 6:
			sort();
			break;

		case 7:
			exit(0);
			break;
		}

		printf("enter 1 continue or 0:");
		scanf("%d", &ch);
	} while (ch == 1);
	return 0;
}

void input() {
	FILE *fp = fopen("book.txt", "a+");

	if (fp == NULL) {
		printf("error");
		exit(0);
	}

	book b;

	printf("Enter aid,title,aname,price,flag:");
	scanf("%d %s %s %d %d", &b.aid, b.title, b.aname, &b.price, &b.flag);

	fwrite(&b, sizeof(book), 1, fp);

	fclose(fp);
}

void print() {
	FILE *fp = fopen("book.txt", "r");

	if (fp == NULL) {
		printf("error");
		exit(0);
	}

	book b;

	printf("\nThe details of the book:\n");

	while (fread(&b, sizeof(book), 1, fp)) {
		printf("%d %s %s %d %d\n", b.aid, b.title, b.aname, b.price, b.flag);
	}

	fclose(fp);
}

int count() {
	book p;
	FILE *fp;
	int count = 0;
	fp = fopen("book.txt", "r");
	if (fp == NULL) {
		printf("\t\t\tError in opening file \n");
		return 1;
	}
	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
	}
	fclose(fp);
	return count;
}

void sort() {
	FILE *fp = fopen("book.txt", "r");

	if (fp == NULL) {
		printf("error");
		exit(0);
	}

	book temp, *b;
	int n = count();
	b = (book*) malloc(n * sizeof(book));

	int i = 0, j;

	while (fread(b + i, sizeof(book), 1, fp)) {
		i++;
	}

	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if ((b + i)->aid > (b + j)->aid) {
				temp = *(b + i);
				*(b + i) = *(b + j);
				*(b + j) = temp;
			}
		}
	}

	printf("\nSorted Data\n");
	for (i = 0; i < n; i++) {
		printf("%d %s %s %d %d\n", (b + i)->aid, (b + i)->title, (b + i)->aname,
				(b + i)->price, (b + i)->flag);
	}

	free(b);
	fclose(fp);
}

void author() {
	FILE *fp = fopen("book.txt", "r");

	if (fp == NULL) {
		printf("error");
		exit(0);
	}

	book b;

	char auname[50];
	printf("enter author name here:");
	scanf("%s", auname);

	while (fread(&b, sizeof(b), 1, fp)) {
		if (strcmp(auname, b.aname) == 0) {
			printf("%d %s %s %d %d\n", b.aid, b.title, b.aname, b.price,
					b.flag);
		}
	}
	fclose(fp);
}

void books() {
	FILE *fp = fopen("book.txt", "r");

	if (fp == NULL) {
		printf("error");
		exit(0);
	}

	book b;

	char bname[40];
	printf("enter book title name here:");
	scanf("%s", bname);

	while (fread(&b, sizeof(b), 1, fp)) {
		if (strcmp(bname, b.title) == 0) {
			printf("%d %s %s %d %d\n", b.aid, b.title, b.aname, b.price,
					b.flag);
		}
	}
	fclose(fp);

}
