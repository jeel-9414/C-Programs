/*
 * c1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[]){
	if(argc!=3){
		printf("Error");
	}

	FILE *fp1=fopen("abc.txt","r");
	FILE *fp2=fopen("abc2.txt","w");

	if(fp1==NULL || fp2==NULL){
		printf("error");
	}

	char ch;
	while(fread(&ch,sizeof(ch),1,fp1)){
//		ch=fgetc(fp1);
//		fputc(ch,fp2);
//		fread(&ch,sizeof(ch),1,fp2);
		fwrite(&ch,sizeof(ch),1,fp2);
	}

	fclose(fp1);
	fclose(fp2);
}

