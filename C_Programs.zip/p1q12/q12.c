/*
 * q12.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

void input(int r,int c,int a[r][c]);
void lar(int r,int c,int a[r][c]);
void sma(int r,int c,int a[r][c]);

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	int a[100][100],r,c;
	printf("enter r and c:");
	scanf("%d %d",&r,&c);

	input(r,c,a);
	lar(r,c,a);
	sma(r,c,a);
	return 0;
}

void input(int r,int c,int a[r][c])
{
	int i,j;

	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			scanf("%d",&a[i][j]);
		}
	}
}

void lar(int r,int c,int a[r][c])
{
	int i,j;
	int large=a[0][0];
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			if(large<a[i][j]){
				large=a[i][j];
			}
		}
	}

	printf("Enter largest elements=%d",large);
}

void sma(int r,int c,int a[r][c])
{
	int i,j;
	int small=a[0][0];

	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			if(small>a[i][j]){
				small=a[i][j];
			}
		}
	}

	printf("the smallest element is=%d\n",small);
}
