/*
 * q5.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
int xlen(char *);
int xcmp(char *,char *);
void cat(char *,char *);
int pal(char *);
void copy(char *);
int main()
{
	char a[50],b[50],*p1,*p2;
	printf("enter a string here:");
	scanf("%s",a);
	/*printf("\nenter b string here:\n");
	scanf("%s",b);*/
	p1=a;
	p2=b;
	/*printf("%d\n",xcmp(a,b));
	cat(a,b);*/

//	printf("\nthe string is=%d",pal(a));

	copy(p1);
	return 0;
}

int xlen(char *a)
{
	int i=0,l1=0;
	while(*(a+i)!='\0'){
		l1++;
		i++;
	}
	return l1;
}

int xcmp(char *a,char *b)
{
	int l1=0,l2=0;
	l1=xlen(a);
	l2=xlen(b);
	int i=0;

	if(l1!=l2){
	     return 1;
	}
	while(*(a+i)!='\0'){
		 if(*(a+i)!=*(b+i)){
			return 1;
			break;
		}
		i++;
	}

	return 0;
}

void cat(char *a,char *b){
	int l1,l2,i=0;
	l1=xlen(a);
//    l2=xlen(b);

    while(*(a+i)!='\0'){
    	*(a+i+l1)=*(b+i);
    	i++;
    }

    *(a+i+l1)='\0';

    printf("%s",a);

}


int pal(char *a){
	int l1=0;

	l1=xlen(a);
	int i=0,j=l1-1;
	while(i<l1/2){
		if(*(a+i)!=*(a+j)){
			return 1;
		}
		i++;
		j--;
	}

	return 0;
}

void copy(char *a){
	char *b;
	int i;
    b=(char *)malloc((i+1)*sizeof(b));
    i=0;

    if(b==NULL){
    	printf("error");
    }

	while(*(a+i)!='\0'){
		*(b+i) = *(a+i);
		i++;
	}

	*(b+i)='\0';
	printf("b=%s",b);
	free(b);
}
