/*
 * abc.c
 *
 *  Created on: 21 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
#define FILENAME "student.dat"
typedef struct
{
int spid;
char name[20];
int c,dbms,p1;
float per;
}student;
void insert();//
void deletebyid();
void update();
void display();//
void search();
void searchbyid();//
void searchbyname();//
void searchbyc();//
void searchbydbms();
void searchbyp1();
void searchbyper();
void sort();
void printmenu();
void printline();
void printheader();
int count();
int main()
{
printmenu();
return 0;
}
void printmenu()
{
int ch=0;int record;
int choice=0;
while(choice==0)
{
printf("\n\n");
printline();
printf("\t\t\t\t 1. Add Student \n");
printf("\t\t\t\t 2. Display Students \n");
printf("\t\t\t\t 3. Search Student \n");
printf("\t\t\t\t 4. Update Student \n");
printf("\t\t\t\t 5. Delete Student \n");
printf("\t\t\t\t 6. Sort Details \n");
printf("\t\t\t\t 7. count \n");
printf("\t\t\t\t 8. Exit \n");
printline();
printf("\n Enter your choice= ");
scanf("%d",&ch);
switch(ch)
{
case 1:
insert();
break;
case 2:
display();
break;

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.c

case 3:
search();
break;
case 4:
update();
break;
case 5:
deletebyid();
break;
case 6:
sort();
break;
case 7:
record=count();
printf("\n%d records in file ",record);
break;
default:
printf("\n Wrong choice");
}
printf("\n Do you want to continue(0-Yes, 1-No)");
scanf("%d",&choice);
}while(choice==0);
}
void printline()
{
printf("\n");
for(int i=0;i<=100;i++)
{

printf("-");

}
printf("\n");
}
void insert()
{
student s;
FILE *fp;
fp=fopen(FILENAME,"a");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
printf("\n Enter spid, name=");
scanf("%d %s", &s.spid,s.name);
printf("\nEnter marks of C, DBMS, Practical-1=");
scanf("%d %d %d",&s.c,&s.dbms,&s.p1);
s.per=(float)(s.c+s.dbms+s.p1)/3;
fwrite(&s,sizeof(s),1,fp);
fclose(fp);
}
void display()
{
student s;
FILE *fp;
int count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
printf("\n");
printline();
printheader();
printline();

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 3 of 10
while(fread(&s,sizeof(s),1,fp))
{
count++;
printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);
}
printf("\n %d records displayed",count);
fclose(fp);
}
void printheader()
{
printf("SPID\tNAME\tC\tDBMS\tPRACTICAL-1\tPERCENTAGE");
}
void searchbyid()
{
student s;
FILE *fp;
int spid,count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");

exit(-1);
}
printf("\nEnter spid to search");
scanf("%d",&spid);
printf("\n");
printline();
printheader();
printline();
while(fread(&s,sizeof(s),1,fp))
{
if(spid==s.spid)
{
count++;

printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);

}
}
if(count==0)
{
printf("\nNo record found");
}
else
{
printf("\n%d record found",count);
}
fclose(fp);
return;
}
void searchbyname()
{
student s;
char name[30];
FILE *fp;
int count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
printf("\nEnter student name to search");
scanf("%s",name);
printf("\n");
printline();
printheader();
printline();

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 4 of 10
while(fread(&s,sizeof(s),1,fp))
{
if(strcmp(name,s.name)==0)
{
count++;

printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);

}
}
if(count==0)
{
printf("\nNo record found with name %s",name);
}
else
{
printf("\n%d matching record found",count);
}
fclose(fp);
return;
}
void searchbyc()
{
student s;
FILE *fp;
int lower,upper,count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
printf("\nEnter lower & upper range for C to search");
scanf("%d %d",&lower,&upper);
printf("\n");
printline();
printheader();
printline();
while(fread(&s,sizeof(s),1,fp))
{
if(s.c>=lower && s.c<=upper)
{
count++;

printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);

}
}
if(count==0)
{
printf("\nNo record found");
}
else
{
printf("\n%d record found",count);
}
fclose(fp);
return;
}
void searchbydbms()
{
student s;
FILE *fp;
int lower,upper,count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 5 of 10

exit(-1);
}
printf("\nEnter lower & upper range for DBMS to search");
scanf("%d %d",&lower,&upper);
printf("\n");
printline();
printheader();
printline();
while(fread(&s,sizeof(s),1,fp))
{
if(s.dbms>=lower && s.dbms<=upper)
{
count++;

printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);

}
}
if(count==0)
{
printf("\nNo record found");
}
else
{
printf("\n%d record found",count);
}
fclose(fp);
return;
}
void searchbyp1()
{
student s;
FILE *fp;
int lower,upper,count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
printf("\nEnter lower & upper range for Practical-1 to search");
scanf("%d %d",&lower,&upper);
printf("\n");
printline();
printheader();
printline();
while(fread(&s,sizeof(s),1,fp))
{
if(s.p1>=lower && s.p1<=upper)
{
count++;

printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);

}
}
if(count==0)
{
printf("\nNo record found");
}
else
{
printf("\n%d record found",count);
}
fclose(fp);
return;
}

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 6 of 10
void searchbyper()
{
student s;
FILE *fp;
int count=0;
fp=fopen(FILENAME,"r");
float lower,upper;
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
printf("\nEnter lower & upper range for percentage to search");
scanf("%f %f",&lower,&upper);
printf("\n");
printline();
printheader();
printline();
while(fread(&s,sizeof(s),1,fp))
{
if(s.per>=lower && s.per<=upper)
{
count++;

printf("\n%d\t%s\t%d\t%d\t%d\t%f",s.spid,s.name,s.c,s.dbms,s.p1,s.per);

}
}
if(count==0)
{
printf("\nNo record found");
}
else
{
printf("\n%d record found",count);
}
fclose(fp);
return;
}
void deletebyid()
{
FILE *fp1,*fp2;
int spid,count=0;
student s;
fp1=fopen(FILENAME,"r");
fp2=fopen("temp.dat","w");
if(fp1==NULL ||fp2==NULL)
{
printf("\n Error in opening file");
exit(-1);
}
printf("Enter SPID of student to delete");
scanf("%d",&spid);
while(fread(&s,sizeof(s),1,fp1))
{
if(s.spid!=spid)
{
count++;
fwrite(&s,sizeof(s),1,fp2);
}
}
fclose(fp1);
fclose(fp2);
fp1=fopen(FILENAME,"w");
fp2=fopen("temp.dat","r");
if(fp1==NULL ||fp2==NULL)

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 7 of 10
{
printf("\n Error in opening file");
exit(-1);
}
while(fread(&s,sizeof(s),1,fp2))
{
fwrite(&s,sizeof(s),1,fp1);
}
fclose(fp1);
fclose(fp2);
return;
}
void update()
{
student s;
FILE *fp1,*fp2;
int spid,count=0,choice;
fp1=fopen(FILENAME,"r");
fp2=fopen("temp.dat","w");
if(fp1==NULL ||fp2==NULL)
{
printf("\n Error in opening file");
exit(-1);
}
printf("Enter SPID of student to update");
scanf("%d",&spid);
while(fread(&s,sizeof(s),1,fp1))
{
if(s.spid==spid)
{
count++;
printf("\n 1. Update Name");
printf("\n 2. Update C Marks");
printf("\n 3. Update DBMS Marks");
printf("\n 4. Update Practical-1 Marks");
printf("\n 5. Enter Whole record");
printf("\n Enter your choice=");
scanf("%d",&choice);
switch(choice)
{
case 1:
printf("Enter new name");
scanf("%s",s.name);
break;
case 2:
printf("Enter Marks of C=");
scanf("%d",&s.c);
s.per=(float)(s.c+s.dbms+s.p1)/3;
break;
case 3:
printf("Enter Marks of DBMS=");
scanf("%d",&s.dbms);
s.per=(float)(s.c+s.dbms+s.p1)/3;
break;
case 4:
printf("Enter Marks of Practical-1=");
scanf("%d",&s.p1);
s.per=(float)(s.c+s.dbms+s.p1)/3;
break;
case 5: printf("Enter New Name,Marks of C, DBMS, Practical-1=");

scanf("%s %d %d %d",s.name,&s.c,&s.dbms,&s.p1);
s.per=(float)(s.c+s.dbms+s.p1)/3;
break;

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 8 of 10

default:
printf("Wrong Choice)");
break;
}
fwrite(&s,sizeof(s),1,fp2);//record with modification
}
else
{
fwrite(&s,sizeof(s),1,fp2);//record without modification
}
}
printf("%d record updated",count);
fclose(fp1);
fclose(fp2);
fp1=fopen(FILENAME,"w");
fp2=fopen("temp.dat","r");
if(fp1==NULL ||fp2==NULL)
{
printf("\n Error in opening file");
exit(-1);
}
while(fread(&s,sizeof(s),1,fp2))
{
fwrite(&s,sizeof(s),1,fp1);
}
fclose(fp1);
fclose(fp2);
return;
}
int count()
{
student s;
FILE *fp;
int count=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
while(fread(&s,sizeof(s),1,fp))
{
count++;
}
fclose(fp);
return count;

}
void sort()
{
student s,*p;
int nrecord=count();
student st[nrecord];
FILE *fp;
int i=0;
fp=fopen(FILENAME,"r");
if(fp==NULL)
{
printf("Error in opening file \n");
exit(-1);
}
// option 1 - using dynamic memory allocation

//File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 9 of 10
p=(struct student *)malloc(nrecord*sizeof(student));
while(fread(p+i,sizeof(s),1,fp))
{
i++;
}
printheader();
printline();
/*for(int i=0;i<nrecord;i++)// check whether data copied successfully in the
memory
{
printf("\n%d\t%s\t%d\t%d\t%d\t%f",(p+i)->spid,(p+i)->name,(p+i)->c,(p+i)-

>dbms,(p+i)->p1, (p+i)->per);
}*/
for(int i=0;i<nrecord;i++)
{
for(int j=i+1;j<nrecord;j++)
{
if((p+i)->per > (p+j)->per)
{

s=*(p+i);
*(p+i)=*(p+j);
*(p+j)=s;

}
}
}
printf("\n");
printf("Sorted data");
printheader();
printline();
for(int i=0;i<nrecord;i++)
{
printf("\n%d\t%s\t%d\t%d\t%d\t%f",(p+i)->spid,(p+i)->name,(p+i)->c,(p+i)->dbms,(p+i)->p1, (p+i)->per);
}
// option 2- Using Variable Length Array
/*while(fread(st+i,sizeof(s),1,fp))
{

i++;

}
printf("\n");
/**/
/*for(int i=0;i<nrecord;i++)
{

printf("\n%d %s %d %d %d

%f",st[i].spid,st[i].name,st[i].c,st[i].dbms,st[i].p1, st[i].per);
}
for(int i=0;i<nrecord;i++)
{
for(int j=i+1;j<nrecord;j++)
{
if(st[i].per>st[j].per)
{
s=st[i];
st[i]=st[j];
st[j]=s;
}
}
}
printf("\n Sorted Records \n");
printline();
for(int i=0;i<nrecord;i++)
{

printf("\n%d %s %d %d %d

File: /home/mscit/Semester/2024-25/...ograms-B/app_student/student.cPage 10 of 10
%f",st[i].spid,st[i].name,st[i].c,st[i].dbms,st[i].p1, st[i].per);
}*/
fclose(fp);
return;
}
void search()
{
int choice=0;
printf("\n \t\t\t1. Search by id");
printf("\n \t\t\t2. Search by name");
printf("\n \t\t\t3. Search by Subject C");
printf("\n \t\t\t4. Search by Subject DBMS");
printf("\n \t\t\t5. Search by Subject Practical-1");
printf("\n \t\t\t6. Search by percentage");
printf("\n Enter your choice =");
scanf("%d",&choice);
switch(choice)
{
case 1: searchbyid();
break;
case 2: searchbyname();
break;
case 3:searchbyc();
break;
case 4:searchbydbms();
break;
case 5:searchbyp1();
break;
case 6:searchbyper();
break;

default:
printf("Wrong Choice");

}
return;
}

