/*
 * 1.c
 *
 *  Created on: 11 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#define N 50
void input(int row,int col,int [row][col]);
void print(int row,int col,int [row][col]);
void isPrime(int row);
void count_prime(int row,int col,int [row][col]);
int main(){
   int r,c,a[N][N];
    printf("Enter row and coln size here:");
    scanf("%d %d",&r,&c);


    if(r>N || c>N){
    	printf("Error");
    }else{
    	input(r,c,a);
    	print(r,c,a);
    	isPrime(a);
    }
	return 0;
}

void input(int row,int col,int a[row][col]){
	printf("Enter Elements here:");
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			printf("Enter elements [%d][%d]:",i,j);
			scanf("%d",&a[i][j]);
		}
	}
}

void print(int row,int col,int a[row][col]){
//	printf("Enter Elements here:");
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				printf("%d\t",a[i][j]);
			}
			printf("\n");
		}
}

int isPrime(int num){
	int count=0;
	for(int i=1;i<=num;i++){

		if(num%i==0){
			count++;

		}
	}

	if(count==2){
		printf("Prime Number\n");
	}else{
		printf("not");
	}
	return 0;
}
