/*
 * q10.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int input(int [],int );
int print(int [],int );
void sort(int [],int);
void lar(int [],int );
void sma(int [],int);

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	int a[100],n;
	printf("Enter Size Here:");
	scanf("%d",&n);

	input(a,n);
	print(a,n);
	sort(a,n);
	print(a,n);
	lar(a,n);
	sma(a,n);
	return 0;
}

int input(int a[],int n){
	printf("Enter elements here:");
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	return 0;
}

int print(int a[],int n)
{
	printf("Elements :");
	for(int i=0;i<n;i++){
		printf("%d\t",a[i]);
	}

	return 0;
}


void sort(int a[],int n)
{
	int i,j,temp;

	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
}


void lar(int a[],int n)
{
	int i;
	int large=a[0];

	for(i=0;i<n;i++){
		if(large<a[i]){
			large=a[i];
		}
	}
	printf("The largest value is=%d",large);
}

void sma(int a[],int n)
{
	int i;
	int small=a[0];

	for(i=0;i<n;i++){
		if(small>a[i]){
			small=a[i];
		}
	}

	printf("the smallest value is=%d",small);
}
