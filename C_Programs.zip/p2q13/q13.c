/*

 * q13.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
void input(int *, int);
int insert(int *, int);
void print(int *, int);
void update(int *, int);
void delete(int *, int);
int main() {
	int n, a[100], *p;
	p = a;
	printf("n:");
	scanf("%d", &n);

	input(p, n);
	insert(p, n);
	print(p, n+1);
	update(p,n);
	print(p,n);
	delete(p,n);
	print(p,n-1);
	return 0;
}

int insert(int *a, int n) {
	int pos, ele;
	printf("enter position:");
	scanf("%d", &pos);

	if (pos <= 0 || pos > n + 1) {
		printf("error");
	}

	printf("enter element:");
	scanf("%d", &ele);

	for (int i = n - 1; i >= pos - 1; i--) {
		*(a + i + 1) = *(a + i);
	}

	*(a + pos - 1) = ele;
	n++;
	return 0;
}

void print(int *a, int n) {
	for (int i = 0; i < n; i++) {
		printf("%d\t", *(a + i));
	}
}

void input(int *a, int n) {
	for (int i = 0; i < n; i++) {
		scanf("%d", (a + i));
	}
}

void update(int *a , int n)
{
	int pos, ele;
		printf("enter position:");
		scanf("%d", &pos);

		if (pos <= 0 || pos > n + 1) {
			printf("error");
		}

		printf("enter element:");
		scanf("%d", &ele);

		for (int i = n ; i >= pos - 1; i--) {
			if(i==pos){
			*(a + pos -1) = ele;
			}
		}

//		*(a + pos - 1) = ele;

}


void delete(int *a, int n)
{
	int pos, ele;
		printf("enter position:");
		scanf("%d", &pos);

		if (pos <= 0 || pos > n + 1) {
			printf("error");
		}


		for (int i = pos ; i <= n - 1; i++) {
			*(a + i - 1) = *(a + i);
		}

		n--;
}
