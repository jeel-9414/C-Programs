/*
 * age.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

typedef struct{
	int d,m,y;
}date;
date input(date);
int age(date,date current);

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	date birth,current;
	birth=input(birth);
	current=input(current);

	age(current,birth);
	return 0;
}

date input(date new){
	printf("enter day,month ,year here:");
	scanf("%d  %d %d",&new.d,&new.m,&new.y);

	return new;
}

int age(date current,date birth){
	int day,month,year;

	day=current.d-birth.d;
	month=current.m-birth.m;
	year=current.y-birth.y;


	if(month<0){
		month=month+12;
		year--;
	}

	printf("Your Age is %d days %d months %d years:",day,month,year);
	return 0;
}
