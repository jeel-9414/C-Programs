/*
 * n.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

void f1();
void f2();
void f3();

int main()
{
	f1();
	return 0;
}

void f1()
{
	printf("Inside f1\n");
	f2();
}
void f2()
{
	printf("Inside F2\n");
	f3();
}
void f3()
{
	printf("Inside F3\n");
	f3();
}
