/*
 * c1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc!=3){
		printf("Error");
	}

	FILE *fp=fopen(argv[1],"r");
	FILE *fp1=fopen(argv[2],"w");

	if(fp==NULL ||  fp1==NULL){
		printf("error");
	}

	char ch;
	while(fread(&ch,sizeof(ch),1,fp)){
		fwrite(&ch,sizeof(ch),1,fp1);
	}

	fclose(fp1);
	fclose(fp);
}
