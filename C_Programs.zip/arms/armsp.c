/*
 * armsp.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int digit(int *);
int pow(int *,int *);
int arms(int *);
int main()
{
	int n;
	printf("enter n:");
	scanf("%d",&n);

	printf("%d",arms(n));
	return 0;
}

int digit(int *n)
{
	int di=0;
     int l=*n;
		while(l>0){
				l=l/10;
				di++;
			}

	return di;
}

int pow(int *b,int *e)
{
	int i,pow=1;
	for(i=1;i<=*e;i++){
		pow=pow * (*b);
	}

	return pow;
}


int arms(int *n)
{
	int no,digit,*d,arm=0;
    int l=*n;
	d=digit(&l);
//	no=*n;

	while(l>0){
		digit=l%10;
		arm=arm+pow(&digit,&d);
		l=l/10;
	}

	if(arm==*n){
		return  0;
	}else{
		return 1;
	}
}



