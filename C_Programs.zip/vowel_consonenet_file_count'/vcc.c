/*
 * vcc.c
 *
 *  Created on: 23 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	FILE *fp=NULL;

	fp=fopen("student.txt","a+");

	if(fp==NULL){
		printf("Error");
		return 1;
	}

    char str[50];

    printf("Enter string here:");
    scanf("%s",str);

    fputs(str,fp);
    fclose(fp);

   FILE *fp1=NULL;

   fp1=fopen("student.txt","r+");

   if(fp1==NULL){
	   printf("error");
	   return 1;
   }

   int countvowel=0,countconsonant=0;
   rewind(fp1);
   while(feof(fp1)==0){
	   if(fgetc(fp1)=='A'||fgetc(fp1)=='E'||fgetc(fp1)=='I'||fgetc(fp1)=='O'||fgetc(fp1)=='U'||fgetc(fp1)=='a'||fgetc(fp1)=='e'||fgetc(fp1)=='i'||fgetc(fp1)=='o'||fgetc(fp1)=='u'){
		   countvowel++;
	   }
	   else{
		   countconsonant++;
	   }
   }

   printf("total vowels=%d and consonants=%d",countvowel,countconsonant);

   fclose(fp1);
   return 0;
}

