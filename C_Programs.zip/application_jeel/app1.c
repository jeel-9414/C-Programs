/*
 * app1.c
 *
 *  Created on: 24 Apr 2025
 *      Author: Jeel Panchal
 */
#include<stdio.h>

typedef struct{
	int  d,m,y;
}date;

typedef struct{
	int ano;
	char name[50];
	date dob;
	char gender[50];
    date idate;
    int mno;
    char address[50];
    int pincode;
}person;

int main(){

}

