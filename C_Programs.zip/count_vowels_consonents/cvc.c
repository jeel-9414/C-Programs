/*
 * cvc.c
 *
 *  Created on: 21 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	FILE *fp=NULL;

	fopen("student.txt","w+");

	if(fp==NULL){
		printf("Error in opening the file\n");
	}
	char str[50];

	printf("Enter string here:");
	gets(str);

	rewind(fp);

	char ch;
	while(!feof(fp)){
        ch=fgetc(fp);
		printf("%c",ch);
	}

	fclose(fp);
	return 0;
}

