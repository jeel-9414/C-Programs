/*
 * prime.c
 *
 *  Created on: 21 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("No. of arguments do not match\n");
		return ;
	}

	int i,count=0;

	int n=atoi(argv[1]);
	for(i=1;i<=n;i++){
		if(n%i==0){
			count++;
		}
	}

	if(count==2){
		printf("Prime Number\n");
	}else{
		printf("Not");
	}
}

