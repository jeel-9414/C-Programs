/*
 * p1.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	int i=0;
	const int *ptr=&i;
	i++;
    (*ptr)++;

	return 0;
}

