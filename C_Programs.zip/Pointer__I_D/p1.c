/*
 * p1.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	int a[3]={11,23,67};

	int *p;
	p=a;

	/*printf("%d\n",++(*p));
//	printf("%d\n",*p);

	printf("%d\n",(*p)++);
	printf("%d\n",*p);

	printf("%d\n",(*p)--);
	printf("%d\n",*p);

	printf("%d\n",--(*p));*/

//	printf("%d %d %d",*(--p),*(--p),*(--p));

	printf("%d %d %d %d",*p++,*p++,*p++,*p++);
	return 0;
}

