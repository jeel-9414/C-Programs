/*
 * uidai.c
 *
 *  Created on: 24 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
#define FILENAME "UIDAI"

typedef struct{
	int ano;
	char name[50];
	char gender[50];
    char address[50];
    int pincode;
}person;

void printline();
void header();
void insert();
void display();
void delete();

int main()
{

	  setvbuf(stdout, NULL, _IONBF, 0);

	int choice,ch;

	printf("\t\t\t************************UIDAI***************************\n\n");
	printf("\n");
	printline();
	printf("\n");
	printf("\n");
	printf("\n");

	do{
		printf("\t\t\t\t1.enter Aaddhar-card details:\n");
		printf("\t\t\t\t2.display Aaddah-card details:\n");
		printf("\t\t\t\t3.search From Aaddhar-card details:\n");
		printf("\t\t\t\t4.Delete Aaddhar-card details:\n");
		printf("\t\t\t\t5.Sort the Aaddhar-card details:\n");
		printf("\t\t\t\t6.count the details of Aaddhar-card holders:\n");
		printf("\t\t\t\t7.Exit:\n");

		printline();
		printf("\n");
		printf("enter the choice here(1-7):");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:insert();
		break;

		case 2:display();
		break;

//		case 3:search();
//		break;

		case 4:delete();
		break;

//		case 5:sort();
//		break;
//
//		case 6:count();
//		break;

		case 7:exit(1);
		break;
		}
		printf("enter 1  if you want to continue or enter 0:");
		scanf("%d",&ch);
	}while(ch==1);
	return 0;
}

void printline()
{
	int i;
	for(i=0;i<90;i++){
		printf("-");
	}
}
void header()
{
	printf("%s\t\t%s\t\t%s\t\t%s\t\t%s\n","Aadhar-Number","Name","Gender","Address","Pincode");
}

void insert()
{
	FILE *fp=fopen(FILENAME,"a+");
	person p;
	if(fp==NULL){
		printf("error");
	}

	printf("enter the aadhar no:");
	scanf("%d",&p.ano);

	printf("enter name here:");
	scanf("%s",p.name);

	printf("enter gender here:");
	scanf("%s",p.gender);

	printf("enter address here:");
	scanf("%s",p.address);

	printf("enter pincode here:");
	scanf("%d",&p.pincode);


	fwrite(&p,sizeof(p),1,fp);
	fclose(fp);
}

void display()
{
	FILE *fp=fopen(FILENAME,"r");

	person p;

	if(fp==NULL){
		printf("error");
	}



	printline();
	printf("\n");
	header();
	printf("\n");
	printline();


	printf("\n");
	//printf("\n");
	while(fread(&p,sizeof(p),1,fp)){
         printf("%d\t\t\t%s\t\t\t%s\t\t\t%s\t\t\t\t%d\n",p.ano,p.name,p.gender,p.address,p.pincode);
	}

	fclose(fp);
}

void delete()
{
	FILE *fp=fopen(FILENAME,"r");
	FILE *fp2=fopen("temp.dat","a");
	person p;
	int ano;

	if(fp==NULL || fp2==NULL){
		printf("error");
	}

	printf("enter aadhar number here:");
	scanf("%d",&ano);

	while(fread(&p,sizeof(p),1,fp)){
		if(ano!=p.ano)
		{
			fwrite(&p,sizeof(p),1,fp2);
		}
	}

	fclose(fp);
	fclose(fp2);

	fp=fopen(FILENAME,"r+");
	fp2=fopen("temp.dat","r");

	if(fp==NULL || fp2==NULL){
		printf("Error");
	}

	while(fread(&p,sizeof(p),1,fp2)){
		fwrite(&p,sizeof(p),1,fp);
	}


	fclose(fp);
	fclose(fp2);

}
