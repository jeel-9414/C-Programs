/*
 * 1.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

struct flags{
	unsigned int flag1:1;
	unsigned int flag2:1;
	unsigned int flag3:1;
};

int main()
{
	struct flags F={1,0,1};

	printf("Flag1:%u\n",F.flag1);
	printf("Flag2:%u\n",F.flag2);
	printf("Flag3:%u\n",F.flag3);

	printf("Size of Flag:%x\n",sizeof(F));
	return 0;
}
