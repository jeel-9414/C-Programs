/*
 * q1.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
void input(int *,int );
void sort(int *,int );
void print(int *,int);
int sum(int *,int );
int isprime(int);
int count(int *,int);
int main()
{
    int a[100],n,*p;
    printf("n:");
    scanf("%d",&n);
    p=a;
    input(p,n);
    sort(p,n);
    print(p,n);
    printf("sum=%d\n",sum(p,n));

    count(p,n);
	return 0;
}

void input(int *a,int n)
{
	for(int i=0;i<n;i++){
		scanf("%d",(a+i));
	}
}

void sort(int *a,int n)
{
	int j,temp;

	for(int i=0;i<n;i++){
		for(j=0;j<n;j++)
		{
			if(*(a+i)>*(a+j))
			{
				temp=*(a+i);
				*(a+i)=*(a+j);
				*(a+j)=temp;
			}
		}
	}
}

void print(int *a,int n)
{
	for(int i=0;i<n;i++){
		printf("%d\t",*(a+i));
	}
}

int sum(int *a,int n){
	int s=0;

	for(int i=0;i<n;i++)
	{
		s=s+*(a+i);
	}
	return s;
}

int isprime(int n)
{
	int i;

	if(n<=1){
		return 0;
	}

		for(i=2;i*i<=n;i++){
			if(n%i==0)
			{
				return 0;
			}
		}
		return 1;
}

int count(int *a,int n)
{
	int i,c=0;

	for(i=0;i<n;i++)
	{
		if(isprime(*(a+i)))
		{
			c++;
		}
	}

	printf("%d",c);
}
