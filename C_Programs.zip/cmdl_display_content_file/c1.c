/*
 * c1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[]){

	if(argc!=2){
		printf("Arguments Not match\n");
	}

	else{
	FILE *fp=fopen("abc.txt","r");

	if(fp==NULL){
		printf("error");
	}

	char ch;
	while(!feof(fp)){
		fread(&ch,sizeof(ch),1,fp);
		printf("%c",ch);
	}

	fclose(fp);
	}
}
