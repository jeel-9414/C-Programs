/*
 * 1.c
 *
 *  Created on: 16 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#define N 50
void input(int r,int c,int (*a)[c]);
void print(int r,int c,int (*a)[c]);

int main()
{
	int r,c;
	printf("r n C:\n");
	scanf("%d %d",&r,&c);

	int a[N][N];
//	int *ptr=&a[0][0];
	input(r,c,a);
	print(r,c,a);
	return 0;
}

void input(int r,int c,int (*a)[c])
{
//	r=2,c=2;
	int i;

	for(i=0;i<r;i++){
		for(int j=0;j<c;j++){
			scanf("%d",(*(a+i)+j));
		}
	}
}

void print(int r,int c,int (*a)[c])
{
//	r=2,c=2;
	int i;

	for(i=0;i<r;i++){
		for(int j=0;j<c;j++){
			printf("%d\t",(*(*(a+i)+j)));
		}
		printf("\n");
	}
}
