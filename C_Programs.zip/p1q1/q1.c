/*
 * q1.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
int year(int );
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	int y;
	printf("enter Year Here:");
	scanf("%d",&y);

	printf("%d",year(y));
	return 0;
}

int year(y){
	if(y%4==0 && (y%100!=0 || y%400==0)){
		return 0;
	}else{
		return 1;
	}
}
