/*
 * q4.c
 *
 *  Created on: 26 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<string.h>
typedef struct {
	int ano;
	char title[50];
	char aname[50];
	int price;
	int flag;
}library;
void display();
void author();
void title();
int count();
void ano();

int main()
{
	library l[3];
	for(int i=0;i<3;i++){
			scanf("%d %s  %s %d %d",&l[i].ano,l[i].title,l[i].aname,&l[i].price,&l[i].flag);
		}

	int choice,ch;
	do{
//		printf("1.Insert:\n");
		printf("2.author\n");
		printf("3.title\n");
		printf("4.count\n");
		printf("5.ano\n");
		printf("6.exit");

		printf("enter choice :");
		scanf("%d",&choice);

		switch(choice){

		case 1:display();
		break;

		case 2:author();
		break;

		case 3:title();
		break;

		case 4:count();
		break;

		case 5:ano();
		break;

		case 6:exit(1);
		break;
		}

		printf("1 or 0:");
		scanf("%d",&ch);
	}while(ch==1);


	return 0;
}


void display()
{
	library l[3];

	for(int i=0;i<3;i++){
		printf("%d %s  %s %d %d",l[i].ano,l[i].title,l[i].aname,l[i].price,l[i].flag);
	}
}

void author()
{
	char author[50];

	printf("author:");
	scanf("%s",author);
	library l[3];
	for(int i=0;i<3;i++){
		if(strcmp(author,l[i].aname)==0){
			printf("%d %s  %s %d %d",l[i].ano,l[i].title,l[i].aname,l[i].price,l[i].flag);
		}
	}
}

void title()
{
	char title[50];

	printf("tile:");
	scanf("%s",title);

	library l[3];
		for(int i=0;i<3;i++){
			if(strcmp(title,l[i].title)==0){
				printf("%d %s  %s %d %d",l[i].ano,l[i].title,l[i].aname,l[i].price,l[i].flag);
			}
		}
}

int  count()
{
	library l[3];
	int count=0;
			for(int i=0;i<3;i++){
				count++;
			}
			return count;
}

void ano()
{
	int i,j;
	library l[3],temp;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			if(l[i].ano>l[j].ano){
				temp=l[i];
				l[i]=l[j];
				l[j]=temp;
			}
		}
	}
}
