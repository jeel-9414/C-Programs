/*
 * 1.c
 *
 *  Created on: 7 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<string.h>

union Student{
	int rno;
	char name[20];
	float per;
//	struct date bod;
};

struct date{
	int d,m,y;
	union Student s1;
};

int main()
{
	struct date d1;

    d1.s1.rno=1;
    printf("%d\n",d1.s1.rno);

    strcpy(d1.s1.name,"Abc");
    printf("%s\n",d1.s1.name);

    d1.s1.per=89.57;
	printf("%.2f\n",d1.s1.per);

	d1.d=9;
	d1.m=8;
	d1.y=2006;

	printf("%d/%d/%d",d1.d,d1.m,d1.y);

	return 0;
}

