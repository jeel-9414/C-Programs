/*
 * 1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc>=2 && argc <=12){
		printf("error");
	}

	int n=argc-1;
	int a[argc-1];

	for(int i=1;i<=n;i++){
		a[i-1]=atoi(argv[i]);
	}

	int temp;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(a[i]>a[j]){
			   temp=a[i];
			   a[i]=a[j];
			   a[j]=temp;
			}
		}
	}

	printf("The Elements:\n");

	for(int i=0;i<n;i++){
		printf("%d\t",a[i]);
	}
}
