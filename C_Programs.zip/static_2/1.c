/*
 * 1.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

void counter();
int main()
{
	for(int i=0;i<3;i++)
	{
		counter();
	}
	return 0;
}

void counter()
{
	static int c=0;
	c++;
		printf("%d\n",c);
}
