/*
 * q14.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
typedef struct{
	int d,m,y;
}date;
date input(date);
int commpare(date ,date );

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	date d1,d2;
	d1=input(d1);
	d2=input(d2);

	printf("the date is =%d",compare(d1,d2));
	return 0;
}

date input(date new){
	printf("enter day,month ,year here:");
	scanf("%d  %d %d",&new.d,&new.m,&new.y);

	return new;
}

int compare(date new,date old){
	if((new.d==old.d && new.m==old.m && new.y==old.y)){
		return 0;
	}else{
		return 1;
	}
}
