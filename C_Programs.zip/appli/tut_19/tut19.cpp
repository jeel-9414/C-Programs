/*
 * tut19.cpp
 *
 *  Created on: 12 Jul 2025
 *      Author: nikul
 */
#include<iostream>
using namespace std;



