/*
 * q1.c
 *
 *  Created on: 27 Jun 2025
 *      Author: nikul
 */
#include <stdio.h>

int main()
{
    int *p, *q;
    int a[6] = {1, 2, 3, 8, 4, 5};
    p = &a[0];             // Pointer to first element
    q = &a[5];             // Pointer to last element

    // Move pointers toward each other
    while (p != q)
    {
        p++;
        q--;
    }

    // For even-length array, we have two center elements (p and q)
    // So we can print both or their average
    printf("Center elements are: %d and %d\n", *q, *p);

    return 0;
}


