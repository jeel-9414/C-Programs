/*
 * Q2.c
 *
 *  Created on: 27 Jun 2025
 *      Author: nikul
 */
#include <stdio.h>

int main()
{
    int *p, *q;
    int a[5] = {1, 2, 3, 4, 5};
    p = &a[0];
    q = &a[4];

    for (int i = 0; i <= 5 /2 ; i++)
    {
        for (int j = 4; j >= 2; j--)
        {
            if ((p + i) == (q + j))
            {
                printf("value are %d", *(p+i));
            }
        }
    }
    // printf("center value is=%d %d", *p, *q);

    return 0;
}

