/*
 * q2.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
void input(int r,int c,int (*a)[100]);
void sort(int r,int c,int (*a)[100]);
void print(int r, int c,int (*a)[100]);
void sum(int r,int c,int (*a)[100]);
int main()
{
	int r,c,a[100][100],*p;


	printf("r,c:\n");
	scanf("%d  %d",&r,&c);
	p=&a[0][0];
	input(r,c,p);
	sort(r,c,p);
	print(r,c,p);
	sum(r,c,p);
	return 0;
}

void input(int r,int c,int (*a)[100])
{
	for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			scanf("%d",*(a+i)+j);
		}
	}
}

void sort(int r,int c,int (*a)[100])
{
	int i,j,temp,d[r*c],k=0;

	for(int i=0;i<r;i++){
			for(int j=0;j<c;j++){
				*(d+k)=*(*(a+i)+j);
				k++;
			}
	}

	for(i=0;i<k;i++)
	{
		for(j=i+1;j<k;j++){

			if(*(d+i)<*(d+j))
			{
				temp=*(d+i);
				*(d+i)=*(d+j);
				*(d+j)=temp;
			}
		}
	}

	k=0;
	for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			*(*(a+i)+j)=*(d+k);
			k++;
		}
	}
}


void print(int r,int c,int (*a)[100]){
	for(int i=0;i<r;i++){
			for(int j=0;j<c;j++){
				printf("%d\t",(*(*(a+i)+j)));
			}
			printf("\n");
		}
}

void sum(int r,int c,int (*a)[100])
{
	int s=0;
	for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			s=s+(*(*(a+i)+j));
		}
	}

	printf("sum=%d",s);
}
