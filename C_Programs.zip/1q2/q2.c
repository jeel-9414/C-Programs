/*
 * q2.c
 *
 *  Created on: 26 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#define N 50
typedef struct {
    char pname[50];
    char tname[50];
    float bavg;
}cricket;

int main(){
	cricket  c[N];
	int n,i;

	printf("n:");
	scanf("%d",&n);

	for(i=0;i<n;i++){
		scanf("%s %s %f",c[i].pname,c[i].tname,&c[i].bavg);
	}
int j;
    for(i=0;i<n;i++){
    	int al=0;
    	printf("team:%s\n",c[i].tname);
    	printf("*********************************\n");
    			for(int j=0;j<n;j++)
    			{
    				if(strcmp(c[i].pname,c[j].pname)==0){
    					 al=1;
    					 break;
    				}

    			}

    			for(int k=0;k<n;k++){
    				if(strcmp(c[i].pname,c[k].pname)==0){
    					printf("Player: %s\n",c[k].pname);
    				}
    			}
    }
  return 0;
}
