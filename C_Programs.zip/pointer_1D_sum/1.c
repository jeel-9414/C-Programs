/*
 * 1.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int sum(int *,int *);

int main()
{
	int a,b;
	printf("Enter a and b here:");
	scanf("%d %d",&a,&b);

	int add;
	add=sum(&a,&b);
	printf("%d",add);
	return 0;
}

int sum(int *a,int *b)
{
	return *a+*b;
}
