/*


 * 1.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul

#include<stdio.h>

int main() {
	FILE *fp = fopen("master.dat", "r");
	FILE *fp1 = fopen("odd.dat", "w");
	FILE *fp2 = fopen("eve.dat", "w");
	int n;

	while (fread(&n, sizeof(n), 1, fp)) {
		if (n % 2 == 0) {
			fwrite(&n, sizeof(n), 1, fp2);
		} else {
			fwrite(&n, sizeof(n), 1, fp1);
		}
	}

	fclose(fp);
	fclose(fp1);
	fclose(fp2);

	fp = fopen("master.dat", "r");
	fp1 = fopen("odd.dat", "r");
	fp2 = fopen("eve.dat", "r");

	printf("master\n");
	while (fread(&n, sizeof(n), 1, fp)) {
		printf("master:\n%d\t", n);
	}

	printf("odd\n");
	while (fread(&n, sizeof(n), 1, fp1)) {
		printf("\n%d\t", n);
	}

	printf("eve\n");
	while (fread(&n, sizeof(n), 1, fp2)) {
		printf("\n%d\t", n);
	}
	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}


*/
#include<stdio.h>

int main() {
    // Open necessary files
    FILE *fp = fopen("master.dat", "r");
    FILE *fp1 = fopen("odd.dat", "w");
    FILE *fp2 = fopen("eve.dat", "w");

    if (fp == NULL || fp1 == NULL || fp2 == NULL) {
        printf("Error opening files.\n");
        return 1;
    }

    int n;

    // Read data from master.dat and partition into odd.dat and eve.dat
    while (fread(&n, sizeof(n), 1, fp)) {
        if (n % 2 == 0) {
            fwrite(&n, sizeof(n), 1, fp2); // Write even numbers
        } else {
            fwrite(&n, sizeof(n), 1, fp1); // Write odd numbers
        }
    }

    // Close partition files
    fclose(fp);
    fclose(fp1);
    fclose(fp2);

    // Reopen files for reading and display their contents
    fp = fopen("master.dat", "r");
    fp1 = fopen("odd.dat", "r");
    fp2 = fopen("eve.dat", "r");

    if (fp == NULL || fp1 == NULL || fp2 == NULL) {
        printf("Error reopening files.\n");
        return 1;
    }

    // Display master file contents
    printf("Master file contents:\n");
    while (fread(&n, sizeof(n), 1, fp)) {
        printf("%d\t", n);
    }
    printf("\n");

    // Display odd file contents
    printf("Odd file contents:\n");
    while (fread(&n, sizeof(n), 1, fp1)) {
        printf("%d\t", n);
    }
    printf("\n");

    // Display even file contents
    printf("Even file contents:\n");
    while (fread(&n, sizeof(n), 1, fp2)) {
        printf("%d\t", n);
    }
    printf("\n");

    // Close all display files
    fclose(fp);
    fclose(fp1);
    fclose(fp2);

    return 0;
}
