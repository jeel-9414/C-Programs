#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int a[] = {1, 2, 3, 4, 5};
    int sum = 0;

    for (auto b : a)
    {
        sum = sum + b;
    }

    cout << sum << endl;
    return 0;
}