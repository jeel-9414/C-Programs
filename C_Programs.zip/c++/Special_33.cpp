#include <iostream>

using namespace std;

int main()
{

    int a, b, c;
    char choice;

    do
    {
    ab:
        cout << "***************************************" << endl;
        cout << "1.Addition" << endl;
        cout << "2.Subtraction" << endl;
        cout << "3.Division" << endl;
        cout << "4.Multiplication" << endl;
        cout << "Q.Quit" << endl;

        cout << "Enter choice here:" << endl;
        cin >> choice;

        if (choice == 'q' || choice == 'Q')
        {
            break;
        }

        if (choice >= '1' && choice <= '4')
        {
            cout << "Enter two numbers: ";
            cin >> a >> b;
        }
        switch (choice)
        {
        case '1':
            c = a + b;
            cout << "Addition is=" << c << endl;
            break;

        case '2':
            c = a - b;
            cout << "Subtraction is=" << c << endl;
            break;

        case '3':
            c = a / b;
            cout << "Division is:" << c << endl;
            break;

        case '4':
            c = a * b;
            cout << "Multiplication is:" << c << endl;
            break;

        default:
            cout << "Try Again...." << endl;
            break;
        }
    } while (true);

    cout << "Thanks!!" << endl;

    return 0;
}