#include<iostream>
#include<iomanip>
#include<limits>
using namespace std;
int main()
{
    float x=123.567890123f;
    double a=123.56789012345667;
    long double aa=123.56789012345667;

    cout<<setprecision(10);
    cout<<"x:"<<x<<endl;
    cout<<"a:"<<a<<endl;
    cout<<"aa:"<<aa<<endl;

    return 0;
}
