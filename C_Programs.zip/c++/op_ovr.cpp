#include <iostream>
using namespace std;

class num
{
    int a, b;

public:
    num(int x = 0, int y = 0)
    {
        a = x;
        b = y;
    }

    num friend operator+(num n1, num n2)
    {
        return n1.a + n2.b;
    }
};

int main()
{
    num n1(1, 2), n2, n3;
    n3 = n1 + n2;
    n3.display();
    return 0;
}