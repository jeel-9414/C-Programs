#include <iostream>

using namespace std;

int main()
{

    int a, b, c;
    char choice;

    do
    {
    ab:
        cout << "***************************************" << endl;
        cout << "1.Addition" << endl;
        cout << "2.Subtraction" << endl;
        cout << "3.Division" << endl;
        cout << "4.Multiplication" << endl;
        cout << "Q.Quit" << endl;

        cout << "Enter choice here:" << endl;
        cin >> choice;

        switch (choice)
        {
        case '1':
            cout << "Enter a and b here:" << endl;
            cin >> a >> b;
            c = a + b;
            cout << "Addition is=" << c << endl;
            break;

        case '2':
            cout << "Enter a and b here:" << endl;
            cin >> a >> b;
            c = a - b;
            cout << "Subtraction is=" << c << endl;
            break;

        case '3':
            cout << "Enter a and b here:" << endl;
            cin >> a >> b;
            c = a / b;
            cout << "Division is:" << c << endl;
            break;

        case '4':
            cout << "Enter a and b here:" << endl;
            cin >> a >> b;
            c = a * b;
            cout << "Multiplication is:" << c << endl;
            break;

        default:
            cout << "Try Again...." << endl;
            break;
        }
    } while (choice != 'q' && choice != 'Q');

    cout << "Thanks!!" << endl;

    return 0;
}