#include <iostream>

using namespace std;

int main()
{
    int n = 0, i, sum = 0;

    do
    {

        sum = sum + n;
        cout << "Enter n here:" << endl;
        cin >> n;
    } while (n >= 0);

    cout << "Sum is:" << sum << endl;
    return 0;
}