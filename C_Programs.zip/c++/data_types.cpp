#include<iostream>
using namespace std;
int main(){
    unsigned short ushort_int=65536;
    signed short signed_short=-6;
    int a=123;
    long int long_int=45678;
    long long int ll_int=1234567890;



    cout<<"size of short int:"<<sizeof(short int)<<endl;
    cout<<"size of int:"<<sizeof(int)<<endl;
    cout<<"size of long int:"<<sizeof(long)<<endl;
    cout<<"size of long long int:"<<sizeof(long long)<<endl;


    cout<<"unsigned short int:"<<ushort_int<<endl;
    cout<<"signed short int:"<<signed_short<<endl;
    cout<<"a:"<<a<<endl;
    cout<<"long_int:"<<long_int<<endl;
    cout<<"long long int:"<<ll_int<<endl;

    return 0;
}