/*
 * f1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	FILE *fp=NULL;

	fp=fopen("abc.txt","w");
	if(fp==NULL){
		printf("Error");
	}

	char str[50];

	printf("Enter String Here:");
	fflush(stdout);
	fgets(str,sizeof(str),stdin);

	int i=0;
	while(str[i]!='\0'){
	fputc(str[i],fp);
	i++;
	}

	rewind(fp);
	char ch;
    while(!feof(fp)){
    	ch=fgetc(fp);
    	printf("%c",ch);
    }

//	fputs(str,fp);



    fclose(fp);
}

