/*




 * Q24.c
 *
 *  Created on: 23 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

void display();
int main() {
	FILE *fp = NULL;
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;

	fp = fopen("master2.dat", "r");
	fp1 = fopen("odd2.dat", "w");
	fp2 = fopen("eve2.dat", "w");
	if (fp == NULL || fp1 == NULL || fp2 == NULL) {
		printf("error");
		return 1;
	}

	int n;
	rewind(fp);

	while (fscanf(fp, "%d", &n) != EOF) {
		if (n % 2 == 0) {
			// Write even numbers to even.dat
			fprintf(fp2, "%d\n", n);
		} else {
			// Write odd numbers to odd.dat
			fprintf(fp1, "%d\n", n);
		}
	}

	fclose(fp);
	fclose(fp1);
	fclose(fp2);

	display();
	return 0;
}

void display() {
	FILE *fp = NULL;
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;

	fp = fopen("master2.dat", "r");
	fp1 = fopen("odd2.dat", "r");
	fp2 = fopen("eve2.dat", "r");

	int n;
	printf("numbers:\n");
	while (fscanf(fp,"%d",&n)!=EOF) {
			printf("%d\n", n);
		}

	printf("odd numbers:\n");
	while (fscanf(fp1,"%d",&n)!=EOF) {
		printf("%d\n", n);
	}

	printf("even Numbers:\n");
	while (fscanf(fp2,"%d",&n)!=EOF) {
		printf("%d\n", n);
	}

	fclose(fp);
	fclose(fp1);
	fclose(fp2);

}
