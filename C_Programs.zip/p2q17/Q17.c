/*
 * Q17.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("no. of match arguments error");
		return 1;
	}

	FILE *fp=fopen(argv[1],"r");

	atoi(argv[1]);
	printf("%d %s",argc,argv[1]);
	if(fp==NULL){
		printf("error");
		return 1;
	}

	char ch;
    while(!feof(fp))
    {
    	ch=fgetc(fp);
    	printf("%c",ch);
    }

    fclose(fp);
}

