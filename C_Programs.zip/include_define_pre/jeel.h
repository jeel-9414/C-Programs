/*
 * jeel.h
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#define PI 3.14
void radius(void);
#define sqr(x) (x)*(x)
#define max(a,b) ((a)>(b)?a:b)

void radius(void)
{
	int r;
	printf("Enter Radius here:");
	fflush(stdout);
	scanf("%d",&r);

#undef PI
#define PI 3.14
	printf("Radius is=%f",PI*r*r);
}
