/*
 * 1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include "jeel.h"

#define pf printf
#define sf scanf
int main()
{
	int a,b;
	pf("Enter a and b here:");
	fflush(stdout);
	sf("%d %d",&a,&b);

	pf("The a and b are=%d %d\n",a,b);
	 pf("square of %d= %d\n", a+b,sqr(a+b));// a+b*a+b
	 pf("Max= %d",max(a+5,b-2));

	 radius();
	return 0;
}

