/*
 * 1.c
 *
 *  Created on: 16 Apr 2025
 *      Author: nikul
 */
/*#include<stdio.h>

int main()
{
	FILE *fp=NULL;

		fp=fopen("abc.txt","a");
		if(fp==NULL){
			printf("Error");
		}

		char str[30];
		printf("Enter string here:");
		fflush(stdout);
		fgets(str,sizeof(str),stdin);




		fputs(str,fp);

		char ch;
		while(!feof(fp)){
			ch=fgetc(fp);
			printf("%c",ch);
		}
  fclose(fp);
}*/


#include <stdio.h>
#include <stdlib.h>

struct Point {
    int x, y;
};

struct Point* createPoint(int a, int b) {
    struct Point* ptr = (struct Point*)malloc(sizeof(struct Point));
    ptr->x = a;
    ptr->y = b;
    return ptr;
}

int main() {
    struct Point* p = createPoint(10, 20);
    printf("x = %d, y = %d\n", p->x, p->y);
    free(p);
    return 0;
}
