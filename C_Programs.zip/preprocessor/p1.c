/*
 * p1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
 #include "string.h"
// #include "/home/mscit/mathematics.h"
 int main()
 {
	 char str1[]="university";
	 printf("length of str1= %d",xstrlen(str1));
	 printf("\nsum of 10,20 = %d",sum(10,20));
	 return 0;
 }

