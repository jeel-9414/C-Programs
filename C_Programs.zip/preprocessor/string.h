/*
 * string.h
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
//#include "p1.c"
#include<string.h>
int xstrlen(char str[]);
int sum(int ,int);

int xstrlen(char str1[]){
int i,count=0;

	for(i=0;str1[i]!='\0';i++){
           count++;
	}
    return count;
}

int sum(int a,int b){
	int sum=0;
	sum=a+b;
	return sum;
}
