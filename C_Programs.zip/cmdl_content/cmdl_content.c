/*
 * cmdl_content.c
 *
 *  Created on: 21 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("Not valid\n");
	}else{
		FILE *fp=NULL;

        fp=fopen(argv[1],"r");

        char ch;

        while(feof(fp)==0){
        	ch=fgetc(fp);
        	printf("%c",ch);
        }

        fclose(fp);
	}
	return 0;
}

