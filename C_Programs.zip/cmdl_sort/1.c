/*

 * 1.c
 *
 *  Created on: 16 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc, char *argv[]) {

//	if (argc != 3) {
//		printf("error");
//	}
//
//	FILE *fp1 = fopen(argv[1], "r");
//	FILE *fp2 = fopen(argv[2], "w");
//
//	if (fp1 == NULL || fp2 == NULL) {
//		printf("error");
//	}
//
//	char ch;
//
//	while (feof(fp1) == 0) {
//		ch = fgetc(fp1);
//		fputc(ch, fp2);
//
//	}
//
//	fclose(fp1);
//	fclose(fp2);
//}

/*	int a[argc-1];
	int n=argc-1;

	if(argc>=2 && argc<-=12){
		for(int i=1;i<=n;i++){
			a[i-1]=atoi(argv[i]);
		}
	}
	*/


}
