/*
 * q15.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

typedef struct {
	int hour,min,sec;
}time;

time input(void);
void print(time);
int validate(time);
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	time t1;
	t1=input();

	print(t1);
	printf("\nthe time is=%d",validate(t1));
	return 0;
}

time input(void)
{
	time t1;
	printf("Enter time here:");
	scanf("%d  %d %d",&t1.hour,&t1.min,&t1.sec);

	return t1;
}

void print(time t1)
{
	printf("The Time is %02d:%02d:%02d",t1.hour,t1.min,t1.sec);
}

int validate(time t1)
{
	if(t1.hour<0 || t1.hour>=24){
		return 1;
	}
	if(t1.min<0 || t1.min>=60){
		return 1;
	}

	if(t1.sec<0 || t1.sec>=60){
		return 1;
	}

     return 0;
}
