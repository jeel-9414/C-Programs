/*
 * q20.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("error");
	}

	FILE *fp=fopen(argv[1],"r");

	int a=atoi(argv[1]);

	int i,count=0;

	for(i=1;i<=a;i++){
		if(a%i==0){
			count++;
		}
	}

	if(count==2){
		printf("prime");
	}else{
		printf("not");
	}
}
