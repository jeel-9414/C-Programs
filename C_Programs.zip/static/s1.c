/*
 * s1.c
 *
 *  Created on: 7 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

void array(int a[5])
{
	for(int i=0;i<5;i++)
	{
		a[i]=a[i]*2;
	}
}
int main()
{
	int a[5]={1,2,3,4,5};

	array(a);
	for(int i=0;i<5;i++){
		printf("%d\t",a[i]);
	}
	return 0;
}

