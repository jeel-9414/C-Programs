/*
 * fact.c
 *
 *  Created on: 21 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
int main(int argc,char *argv[])
{
	int n,fact=1;
	if(argc!=2)
	{
		printf("error");
		exit(-1);
	}
	n=atoi(argv[1]);

	for(int i=1;i<=n;i++){
		fact=fact*i;
	}

	printf("\n Factorial=%d\n",fact);
	return 0;
}

