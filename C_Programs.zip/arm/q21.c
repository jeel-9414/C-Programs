/*
 * q21.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int count_digit(int);
int power(int, int);
int isArm(int);

int main() {
	int n;
	printf("n:");
	scanf("%d", &n);

//	printf("%d",count_digit(n));

	printf("%d",isArm(n));
	return 0;
}

int count_digit(int n) {
	int digit = 0;
	while (n > 0) {

		n = n / 10;
		digit++;

	}


	return digit;
}

int power(int b,int e)
{
	int i=0,pow=1;

	for(i=1;i<=e;i++){
		pow=pow*b;
	}

	return pow;
}


int isArm(int n){
	int no,d,digit,arm=0;

	no=n;
	d=count_digit(n);
	while(n>0)
	{
		digit=n%10;
		arm=arm+power(digit,d);
		n=n/10;
	}

	if(arm==no){
		return 0;
	}else{
		return 1;
	}
}
