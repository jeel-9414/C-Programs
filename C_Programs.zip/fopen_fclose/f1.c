/*
 * f1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
int main()
{
	FILE *fp=fopen("abc.txt","w");

	if(fp==NULL){
		printf("error");
	}
	char str[30];
	printf("Enter String Here:");
//	scanf("%s",str);
	fgets(str,sizeof(str),stdin);

	fputs(str,fp);

	fclose(fp);
}

