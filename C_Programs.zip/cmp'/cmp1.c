/*
 * cmp1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int cmp(char *a, char *b) {
	int l1 = 0, l2 = 0;
	for (int i = 0; a[i] != '\0'; i++) {
		l1++;
	}

	for (int i = 0; b[i] != '\0'; i++) {
		l2++;
	}

	if (l1 != l2) {
		return 1;
	}
	int i = 0;
	while (*(a + i) != '\0') {
		if (*(a + i) != *(b + i)) {
			return 1;
		}
		i++;
	}

	return 0;
}

int cat(char *a, char *b) {
	int l1 = 0;
	for (int i = 0; a[i] != '\0'; i++) {
		l1++;
	}
	int i = 0;
	while (*(b + i) != '\0') {
		*(a + l1 + i) = *(b + i);
		i++;
	}

	*(a + l1 + i) = '\0';
	printf("\n%s", a);
}

int pal(char *a) {
	int i, j;
	int l1 = 0;
	for (int i = 0; a[i] != '\0'; i++) {
		l1++;
	}

	for(i=0;i<l1/2;i++){
		for(j=l1-1-i;j>=l1/2;j--){
			if(*(a+i)!=*(a+j)){
				return 0;
			}
			break;
		}
	}

	return 1;
}

int reverse(char *a){
	int i,j;


}
int main() {
	char a[20], b[20];
	printf("enter :");
	scanf("%s", a);

//	printf("the str is:%d", cmp(a, b));
//	cat(a, b);
	printf("\n%d",pal(a));
	return 0;
}

