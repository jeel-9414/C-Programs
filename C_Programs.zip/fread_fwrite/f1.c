/*
 * f1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<string.h>
int main()
{
	FILE *fp=NULL;

	fp=fopen("abc.txt","w+");

	if(fp==NULL){
		printf("error");
	}

	char str[40];
	printf("Enter String Here:");
	fflush(stdout);
	fgets(str,sizeof(str),stdin);

//	fwrite(str,sizeof(str),strlen(str),fp);

	fprintf(fp,"%s",str);
	rewind(fp);

	while(fscanf(fp,"%s",str)==1){
		printf("%s",str);
	}


	/*while(!feof(fp)){
        fread(str,sizeof(str),1,fp);
		printf("%s",str);
	}*/

	/*while(fread(str,sizeof(str),1,fp)>0)
	printf("%s",str);*/

	/*rewind(fp);*/

	/*while (fread(str, sizeof(char), sizeof(str) - 1, fp) > 0) {
//	    str[sizeof(str) - 1] = '\0';  // null-terminate for safety
	    printf("%s", str);
	}
*/
	/*char str[30];

	while(!feof(fp)){
		fgets(str,sizeof(str),fp);
		printf("%s",str);
	}*/


	fclose(fp);
}

