/*
 * 1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("error");
	}

	FILE *fp=fopen(argv[1],"r");

	if(fp==NULL){
		printf("error");
	}

	char ch;
	while(fread(&ch,sizeof(ch),1,fp)){
		printf("%c",ch);
	}
}
