/*

 * count.c
 *
 *  Created on: 23 Mar 2025
 *      Author: nikul
*/
#include<stdio.h>
#include<stdlib.h>
typedef struct {
	int rollno;
	char name[20];
	float per;
} stu;
void display();
int count();
void write();
int main() {
	write();
	display();
	count();
	return 0;
}
void write() {
	FILE *fp = fopen("student.dat", "a+");
	if (fp == NULL) {
		printf("Error: Cannot open file for writing.\n");
		exit(1);
	}

	stu s;
	printf("Enter roll number, name, and percentage for student\n");
	scanf("%d %s %f", &s.rollno, s.name, &s.per);
	fprintf(fp, "%d %s %.2f\n", s.rollno, s.name, s.per);


	fclose(fp);
	printf("Records written successfully.\n");
}

void display() {
	stu s;
	FILE *fp;
	int count = 0;
	fp = fopen("student.dat", "a+");
	if (fp == NULL) {
		printf("Error in opening file \n");
		exit(-1);
	}

	rewind(fp);
	printf("The record of Students\n");
	printf("----------------------------------\n");

	while (fscanf(fp,"%d %s %f",&s.rollno,s.name,&s.per)!=EOF) {
		count++;
		printf("%d\t%s\t\t\t%f\n", s.rollno, s.name, s.per);
	}
	printf("\n %d records displayed\n", count);
	fclose(fp);
}

int count() {
	FILE *fp;
	stu s;

	fp = fopen("student.dat", "r");

	if (fp == NULL) {
		printf("error");
	}

	int count = 0;
	rewind(fp);
	while (fread(&s, sizeof(s), 1, fp) == 1) {
		count++;
	}

	printf("total Count of record:%d", count);
	fclose(fp);
	return 0;
}


