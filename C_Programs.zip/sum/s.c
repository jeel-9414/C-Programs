/*
 * s.c
 *
 *  Created on: 26 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc!=3){
		printf("error");
	}

	int a,b;
	a=atoi(argv[1]);
	b=atoi(argv[2]);

	printf("%d",a+b);
}

