#include<stdio.h>
#define N 50

void input(int a[N], int n);
void print(int a[N], int n);

int main(){
    int a[N],n;
    printf("Enter Size Here:");
    scanf("%d", &n);

    input(a, n);
    print(a, n);
    return 0;
}

void input(int a[N], int n){
    int i;
    for (i = 0; i < n;i++){
        printf("Enter the element number a[%d]:", i);
        scanf("%d", &a[i]);
    }
}

void print(int a[N],int n){
    int i;
    for (i = 0; i < n;i++){
        printf("%d\t",a[i]);
    }
}
