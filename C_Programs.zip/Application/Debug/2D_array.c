#include<stdio.h>
#include<stdlib.h>
#define N 50
void insert(int a[N][N], int r, int c);
void print(int a[N][N], int r, int c);
void delete(int a[N][N], int r, int c);
void search(int a[N][N], int r, int c);
void sort(int a[N][N], int r, int c);

int main(){
    int r, c,a[N][N];
    printf("Enter The Row and Column Size  here:");
    scanf("%d %d", &r, &c);

    if(r>N || c>N){
        printf("Error:Size is Exceeding by it's Limit\n");
        exit(0);
    }

    insert(a, r, c);
    delete(a, r, c);
    printf("After Deletion of an Element from the Array:\n");
    print(a, r, c);
    return 0;
}

void insert(int a[N][N], int r, int c){
    int i,j;
    for (i = 0; i < r;i++){
        for (j = 0; j < c;j++){
            printf("Enter the Element a[%d][%d]:", i, j);
            scanf("%d", &a[i][j]);
        }
    }
}

//option 1:by Element:------->
/*void delete(int a[N][N], int r, int c){
    int i,j,ele,flag=0;

    printf("Enter the Element which you want to delete:\n");
    scanf("%d", &ele);

    for (i = 0; i < r;i++){
        for (j = 0; j < c;j++){
            if(a[i][j]==ele){
                a[i][j] = 0;
                flag = 1;
                break;
            }
        }
    }

    if(flag==0){
        printf("No elements Found for deletion\n");
        exit(0);
    }
}*/

//option 2:by index ----->
void delete(int a[N][N], int r, int c){
    int i, j, n, m;
    printf("Enter the index for deletion of an Element in [i][j] manner:");
    scanf("%d %d", &m, &n);

    if(n>=i || m>=j || n<0 || m<0){
        printf("Error:The index size is not proper");
        exit(0);
    }

    for (i = 0; i < r;i++){
        for (j = 0; j < c;j++){
            if(i==n && j==m){
                a[i][j] = 0;
            }
        }
    }
}

    void print(int a[N][N], int r, int c)
    {
        int i, j;
        for (i = 0; i < r; i++)
        {
            for (j = 0; j < c; j++)
            {
                printf("%d\t", a[i][j]);
            }
            printf("\n");
        }
}