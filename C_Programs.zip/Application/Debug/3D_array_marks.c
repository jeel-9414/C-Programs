#include<stdio.h>
#include<stdlib.h>
#define N 50

void input(int a[N][N][N], int r, int c, int e);
void print(int a[N][N][N], int r, int c, int e);

int main(){
    int r, c, e,a[N][N][N];
    printf("Enter the row,column and total Element in the array:");
    scanf("%d %d %d", &r, &c, &e);

    if(r>N || c>N || e>N){
        printf("Error:the size is not proper");
        exit(0);
    }

    input(a, r, c, e);
    print(a, r, c, e);
    return 0;
}

void input(int a[N][N][N], int r, int c, int e){
    int i, j, k;
    printf("Enter the Marks of students:\n");
    for (int i = 0; i < r;i++){
        for (int j = 0; j < c;j++){
            for (int k = 0; k < e;k++){
                printf("Enter index of a[%d][%d][%d]:", i, j, k);
                scanf("%d", &a[i][j][k]);
            }
        }
    }
}


void print(int a[N][N][N], int r, int c, int e){
    int i, j, k;
    for (int i = 0; i < r;i++){
        printf("Layer %d:\n",i+1);
        for (int j = 0; j < c;j++){
            for (int k = 0; k < e; k++){
                printf("%d\t", a[i][j][k]);
            }
            printf("\n");
        }
        printf("\n");
    }
}
