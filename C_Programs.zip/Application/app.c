/*
 * app.c
 *
 *  Created on: 21 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
#define FILENAME "UIAI"
typedef struct {
	int d, m, y;
} date;

typedef struct {
	int ano;
	char name[20];
	date dob;
	char gender[20];

	date i_date;
	long int mno;
	char address1[25];
	char address2[25];
	int pincode;
} person;

void insert();

// void search();
 void searchbyano();
 /* void searchbyname();
 void searchbydob();
 void searchbygender();
 void searchbyi_date();
 void searchbypincode();
 void update();
 void updatebyname();
 void updatebydob();
 void updatebygender();
 void updatebyi_date();
 void updatebymno();
 void updatebyaddress1();
 void updatebyaddress2();
 void updatebypincode();
 void delete();
 void sort();
 //void sortbyano();
// void sortbyname();
// void sortbypincode();
// void sortbygender();*/
void display();
void printline();
void printmenu();
void header();


int main() {

	header();
	insert();
	display();
	searchbyano();
	return 0;
}

void printline() {
	printf("\n");
	for (int i = 0; i <= 122; i++) {

		printf("-");

	}
	printf("\n");
}


void header() {
	printline();

	printf("Addhar no\t\tName\t\tBirth Date\t\tGender\t\tIssue Date\t\tMobile NO\t\tAddress Line 1\t\tPincode");

	printline();
}

void insert() {
	person p;
	FILE *fp=NULL;

	fp = fopen(FILENAME, "a+");
	if (fp == NULL) {
		printf("Error:File Doesn't exist\n");
	}

	e: printf("\nEnter Your Aadhar Number Here: ");
	scanf("%d", &p.ano);


	person temp;
	temp.ano = p.ano;
	int count = 0;
	rewind(fp);

	while (fread(&p,sizeof(p),1,fp)==1) {
		if (p.ano == temp.ano) {
			count++;
			break;
		}
	}

	if (count > 0 ) {
		printf("Already Exist Number\n");
		goto e;
	}
	printf("Enter name, birth date, gender : ");
	scanf("%s %d %d %d %s", p.name, &p.dob.d, &p.dob.m, &p.dob.y, p.gender);

	printf("Enter mobile no & issue date : ");
	scanf("%ld %d %d %d", &p.mno, &p.i_date.d, &p.i_date.m, &p.i_date.y);

	printf("Enter Address line 1 & 2 = ");
	scanf("%s %s", p.address1, p.address2);

	printf("Enter pincode = ");
	scanf("%d", &p.pincode);
	fwrite(&p, sizeof(p), 1, fp);

	fclose(fp);
}

void display() {
	person p;
	FILE *fp=NULL;

	fp = fopen(FILENAME, "a+");
	if (fp == NULL) {
		printf("Error in opening file \n");
	}
	printf("\n");
	printline();
	header();
	printline();

	int c=0;
	while (fscanf(fp,"%d %s %d %d-%d-%d %s %d-%d-%d %ld %s %d",&p.ano,p.name,&p.dob.d,&p.dob.m,&p.dob.y,p.gender,&p.i_date.d,&p.i_date.m,&p.i_date.y,&p.mno,p.address1,p.address2,&p.pincode)==9) {
		c++;
		printf("\n%d\t\t%s\t\t\t%d-%d-%d\t\t\t%s\t\t%d-%d-%d\t\t%ld\t\t%s\t\t%s\t\t%d\n",
				p.ano, p.name, p.dob.d, p.dob.m, p.dob.y, p.gender, p.i_date.d,
				p.i_date.m, p.i_date.y, p.mno, p.address1,p.address2,p.pincode);
	}
	printf("\n %d records displayed", c);
	fclose(fp);
}


