/*
 * 1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	FILE *fp=fopen("master.dat","r");
	FILE *fp1=fopen("odd1.dat","w");
	FILE *fp2=fopen("eve1.dat","w");

	int i;
	while(fread(&i,sizeof(i),1,fp)){
		if(i%2==0){
			fwrite(&i,sizeof(i),1,fp2);
		}else{
			fwrite(&i,sizeof(i),1,fp1);
		}
	}


	fclose(fp);
	fclose(fp1);
	fclose(fp2);

	fp=fopen("master.dat","r");
	fp1=fopen("odd1.dat","r");
	fp2=fopen("eve1.dat","r");
	printf("master\n");
	while(fread(&i,sizeof(i),1,fp)){
		printf("%d\n",i);
	}

	printf("odd\n");
	while(fread(&i,sizeof(i),1,fp1)){
		printf("%d\n",i);
	}

	printf("even\n");
	while(fread(&i,sizeof(i),1,fp2)){
			printf("%d\n",i);
		}

	fclose(fp);
		fclose(fp1);
		fclose(fp2);
}

