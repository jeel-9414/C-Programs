/*
 * q22.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

#include <stdio.h>

void inputArray(int a[], int n);
void sortArray(int a[], int n);
void printArray(int a[], int n);
void merge(int a[],int b[],int n,int m,int c[]);
void p1(int a[],int n);
int main() {
    int n1, n2;

    // Input size of arrays
    printf("Enter the size of the first array: ");
    scanf("%d", &n1);
    printf("Enter the size of the second array: ");
    scanf("%d", &n2);

    int a1[n1], a2[n2],c[2*n1];

    // Input elements of both arrays
    printf("Enter elements of the first array:\n");
    inputArray(a1, n1);
    printf("Enter elements of the second array:\n");
    inputArray(a2, n2);

    // Sort both arrays
    sortArray(a1, n1);
    sortArray(a2, n2);

    merge(a1,a2,n1,n2,c);
    // Display sorted arrays
    printf("Sorted first array:\n");
    printArray(a1, n1);

    p1(c,2*n1);
//    printf("Sorted second array:\n");
//    printArray(a2, n2);

    return 0;
}

void inputArray(int a[], int n) {
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
}

void sortArray(int a[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}

void printArray(int a[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

void merge(int a[],int b[],int n,int m,int c[])
{
	int i;
	for(i=0;i<n;i++){
		c[i]=a[i];
	}

	for(i=0;i<n;i++){
		c[n+i]=b[i];
	}
}

void p1(int a[],int n)
{
	int i;
	for(i=0;i<10;i++)
	{
		printf("%d\t",a[i]);
	}
}
