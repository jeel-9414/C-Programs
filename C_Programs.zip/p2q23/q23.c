/*

 * q23.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
*/
#include<stdio.h>
#include<string.h>
int main()
{
	FILE *fp=NULL;

	fp=fopen("student.txt","w");

	char str[50];

	printf("enter content here:");
	gets(str);
	fwrite(str,sizeof(char),strlen(str),fp);

	fclose(fp);

	fp=fopen("student.txt","r");
	rewind(fp);
	int cv=0,cc=0;
	while(!feof(fp)){
		char ch=fgetc(fp);
		if(ch=='A' ||ch=='E' ||ch=='I' ||ch=='O' ||ch=='U' ||ch=='a' ||ch=='e' ||ch=='i' ||ch=='o' ||ch=='u'){
			cv++;
		}else if(ch!=EOF){
			cc++;
		}
	}

	printf("v=%d c=%d",cv,cc);
	fclose(fp);
}


/*
#include<stdio.h>

int main() {
    FILE *fp = NULL;

    // Open file for writing
    fp = fopen("student.txt", "w");
    if (fp == NULL) {
        printf("Error: File cannot be opened.\n");
        return 1;
    }

    char str[50];
    printf("Enter content here: ");
    gets(str); // Keeping `gets` as per your logic

    // Write to file
    fwrite(str, sizeof(char), strlen(str), fp);
    fclose(fp);

    // Open file for reading
    fp = fopen("student.txt", "r");
    if (fp == NULL) {
        printf("Error: File cannot be opened.\n");
        return 1;
    }

    rewind(fp); // Move file pointer to the beginning
    int cv = 0, cc = 0;
    char ch;

    while (!feof(fp)) { // Read till end of file
        ch = fgetc(fp); // Get one character

        // Count vowels and everything else falls under consonants
        if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ||
            ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
            cv++; // Vowel counter
        } else if(ch!=EOF) {
            cc++; // Everything else counts as consonant
        }
    }

    printf("Vowels: %d, Consonants: %d\n", cv, cc);
    fclose(fp);

    return 0;
}
*/
