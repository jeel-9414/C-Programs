/*
 * app1.c
 *
 *  Created on: 29 Mar 2025
 *      Author: nikul
 */
/*
 * aadhar2.c
 *
 *  Created on: 24-Mar-2025
 *      Author: Krisha Patel
 */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define mainfile "udiai.txt"
#define temp "temp.txt"
typedef struct
{
	int day,month,year;
}date;

typedef struct
{
	int ano;
	char name[15];
	date dob;
	char gender[9];
	date i_date;
	char mno[10];
	int pincode;
	char address[40];
}person;

void printline(void);
void header(void);
void insert(void);
void display(void);
void searchbyid(void);
void searchbyname(void);
void searchbydob(void);
void searchbygender(void);
void searchbyi_date(void);
void searchbypincode(void);
void searchbymno(void);
void update(void);
void sortbyiddesc(void);
void sortbyidasc(void);
void sortbynameasc(void);
void sortbynamedesc(void);
void sortbydobasc(void);
void sortbydobdesc(void);
void sortbyidateasc(void);
void sortbyidatedesc(void);
void sortbypincodeasc(void);
void sortbypincodedesc(void);
void print(person );
void delete(void);
void sort(void);
void search(void);
void printmenu(void);
void printui(void);
int count(void);

int main()
{
	printmenu();
	return 0;
}

void printline(void)
{
	printf("\n");
	for(int i=0;i<168;i++)
	{
	printf("-");
	}printf("\n");
	return ;
}

void header(void)
{
	printui();
	printline();
	printf("    %-15s%-18s%-15s%-13s%-15s%-13s%-9s%-45s","Aadhar No","Name","Birth Date","Gender","Issue Date","Mobile No","Pincode","Address");
	printline();
	return ;
}

void print(person p)
{
    printf("\n    %-15d%-18s%2d-%2d-%-9d%-13s%2d-%2d-%-9d%-13s%-9d%-45s",
           p.ano, p.name, p.dob.day, p.dob.month, p.dob.year,
           p.gender, p.i_date.day, p.i_date.month, p.i_date.year,
           p.mno, p.pincode, p.address);
    return ;
}

void fprint(person p,FILE *f)
{
    fprintf(f,"\n%-15d%-18s%2d-%2d-%-9d%-13s%2d-%2d-%-9d%-13s%-9d%-45s",
           p.ano, p.name, p.dob.day, p.dob.month, p.dob.year,
           p.gender, p.i_date.day, p.i_date.month, p.i_date.year,
           p.mno, p.pincode, p.address);
    return ;
}


void insert(void)
{
	person p;
	FILE *fp;
	fp=fopen(mainfile,"a+");
	if(fp==NULL)
	{
		printf("\nError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter details for a person");
	printf("\n\t\t\tEnter the Aadhar no : ");
	fflush(stdout);
	scanf(" %d",&p.ano);
	int no=p.ano;
	rewind(fp);

	while(fread(&p,sizeof(p),1,fp))
		{
			if(no==p.ano)
		{
			printf("\n\t\t\tUnavailable Aadhar number\n");
			fclose(fp);
			return ;
		}
	}
	fseek(fp, 0, SEEK_END);
	p.ano=no;

	c:printf("\t\t\tEnter name : ");
	fflush(stdout);
	scanf(" %s",p.name);
	char name[15];
	strcpy(name,p.name);

	int len=strlen(name);
	for(int i=0;i<len;i++)
	{
		if((name[i]>=65 && name[i]<=90) || (name[i]>=97 && name[i]<=122))
		{
			goto a;
		}
		else
		{
			printf("\n\t\t\tThe name should be in alphabets\n");
			goto c;
		}
	}


	a:printf("\t\t\tEnter Birth date in DD-MM-YYYY format : ");
	fflush(stdout);
	scanf(" %d-%d-%d",&p.dob.day,&p.dob.month,&p.dob.year);
	if(p.dob.day>=31 || p.dob.day<=0 || p.dob.month<=0 || p.dob.month>12 || p.dob.year<=0)
	{
		printf("\nInvalid Date\n");
		goto a;
	}
	else if(p.dob.day<=31 && (p.dob.month==1 || p.dob.month==3 || p.dob.month==5 || p.dob.month==7 || p.dob.month==8 || p.dob.month==10 || p.dob.month==12 ))
	{
		goto e;
	}
	else if(p.dob.day<=30 && (p.dob.month==4 || p.dob.month==6 || p.dob.month==9 || p.dob.month==11) )
	{
		goto e;
	}
	else if(p.dob.day<=29 && p.dob.month==2 && p.dob.year%4==0)
	{
		goto e;
	}
	else if(p.dob.day<=28 && p.dob.month==2 && p.dob.year%4!=0)
	{
		goto e;
	}
	else
	{
		printf("\n\t\t\tInvalid Date\n");
		goto a;
	}


	e:printf("\t\t\tEnter gender : ");
	fflush(stdout);
	scanf(" %s",p.gender);
	char gender[9];
	strcpy(gender,p.gender);
	int n=strlen(gender);
	for(int i=0;i<n;i++)
	{
		if((gender[i]>=65 && gender[i]<=90) || (gender[i]>=97 && gender[i]<=122))
		{
			if(gender[i]>=65 && gender[i]<=90)
			{
				gender[i]=gender[i]+32;
			}
		}
		else
		{
			printf("\n\t\t\tThe Gender should be in alphabets\n");
			goto e;
		}
	}
	if((strcmp(gender,"female")==0) || (strcmp(gender,"male")==0) || (strcmp(gender,"other")==0))
	{
		goto f;
	}
	else
	{
		printf("\n\t\t\tInvalid gender\n");
		goto e;
	}



	f:printf("\t\t\tEnter issue date DD-MM-YYYY format : ");
	fflush(stdout);
	scanf(" %d-%d-%d",&p.i_date.day,&p.i_date.month,&p.i_date.year);

	if(p.i_date.day>=31 || p.i_date.day<=0 || p.i_date.month<=0 || p.i_date.month>12 || p.i_date.year<=0)
	{
		printf("\nInvalid Date\n");
		goto f;
	}
	else if(p.i_date.day<=31 && (p.i_date.month==1 || p.i_date.month==3 || p.i_date.month==5 || p.i_date.month==7 || p.i_date.month==8 || p.i_date.month==10 || p.i_date.month==12 ))
	{
		goto h;
	}
	else if(p.i_date.day<=30 && (p.i_date.month==4 || p.i_date.month==6 || p.i_date.month==9 || p.i_date.month==11) )
	{
		goto h;
	}
	else if(p.i_date.day<=29 && p.i_date.month==2 && p.i_date.year%4==0)
	{
		goto h;
	}
	else if(p.i_date.day<=28 && p.i_date.month==2 && p.i_date.year%4!=0)
	{
		goto h;
	}
	else
	{
		printf("\n\t\t\tInvalid Date\n");
		goto f;
	}




	h:printf("\t\t\tEnter mobile no : ");
	fflush(stdout);
	scanf(" %s",p.mno);
	if(strlen(p.mno)!=10)
	{
		l:
		printf("\n\t\t\tInvalid mobile no\n");
		goto h;
	}
	char mo[10];
	strcpy(mo,p.mno);
	for(int i=0;i<10;i++)
	{
		if(mo[i]>=48 && mo[i]<=57)
		{
			goto k;
		}
		else
			goto l;
	}

	k:printf("\t\t\tEnter pincode (In digits): ");
	fflush(stdout);
	scanf(" %d",&p.pincode);
	int pin=p.pincode;
	int count=0;
	while(pin>0)
	{
		count++;
		pin=pin/10;
	}
	if(count!=6)
	{
		printf("\n\t\t\tPincode must be in 6 digits\n");
		goto k;
	}


	printf("\t\t\tEnter address : ");
	fflush(stdout);
	scanf(" %s",p.address);
	fwrite(&p,sizeof(p),1,fp);
	fclose(fp);

	return ;
}

void display(void)
{
	person p;
	FILE *fp;
	int count=0;
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	rewind(fp);
	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		print(p);
		count++;
	}

	printf("\n    %d records found",count);
	fclose(fp);
	return ;
}

void searchbyid(void)
{
	person p;
	FILE *fp;
	int count=0,ano;
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter Aadhar no you want to search : ");
	fflush(stdout);
	scanf("%d",&ano);
	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		if(ano==p.ano)
		{
			print(p);
			count++;
		}
	}
	printf("\n    %d records found",count);
	fclose(fp);
	return ;
}

void searchbyname(void)
{
	person p;
	FILE *fp;
	int count=0;
	char name[15];
	char tempname[15];
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter name you want to search : ");
	fflush(stdout);
	scanf("%s",name);
	int n=strlen(name);
	for(int i=0;i<n;i++)
	{
		if(name[i]>=65 && name[i]<=90)
		{
			name[i]=name[i]+32;
		}
	}

	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		strcpy(tempname,p.name);
		for(int i=0;i<n;i++)
		{
			if(tempname[i]>=65 && tempname[i]<=90)
			{
				tempname[i]=tempname[i]+32;
			}
		}

		if((strcmp(name,tempname))==0)
		{
			print(p);
			count++;
		}
	}
	printf("\n    %d records found",count);
	fclose(fp);
	return ;
}

void searchbydob(void)
{
	person p;
	FILE *fp;
	int count=0,day,month,year;
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter birth date you want to search : ");
	fflush(stdout);
	scanf("%d-%d-%d",&day,&month,&year);
	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		if((day==p.dob.day) && (month==p.dob.month) && (year==p.dob.year))
		{
			print(p);
			count++;
		}
	}
	printf("\n    %d records found",count);
	fclose(fp);
}

void searchbygender(void)
{
	person p;
	FILE *fp;
	int count=0;
	char gender[9];
		fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter gender you want to search : ");
	fflush(stdout);
	scanf("%s",gender);

	int n=strlen(gender);
	for(int i=0;i<n;i++)
	{
		if(gender[i]>=65 && gender[i]<=90)
		{
			gender[i]=gender[i]+32;
		}
	}

	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		char tempgender[9];
		strcpy(tempgender,p.gender);
		for(int i=0;i<n;i++)
		{
			if(tempgender[i]>=65 && tempgender[i]<=90)
			{
				tempgender[i]=tempgender[i]+32;
			}
		}

		if((strcmp(gender,tempgender))==0)
		{
			print(p);
			count++;
		}
	}
	printf("\n    %d records found",count);
	fclose(fp);
}

void searchbyi_date(void)
{
	person p;
		FILE *fp;
		int count=0,day,month,year;
		fp=fopen(mainfile,"r");
		if(fp==NULL)
		{
			printf("\nError in opening");
			exit(-1);
		}
		printf("\n\t\t\tEnter issue date you want to search : ");
		fflush(stdout);
		scanf("%d-%d-%d",&day,&month,&year);
		header();
		while(fread(&p,sizeof(p),1,fp))
		{
			if((day==p.i_date.day) && (month==p.i_date.month) && (year==p.i_date.year))
			{
				print(p);
				count++;
			}
		}
		printf("\n    %d records found",count);
		fclose(fp);
}

void searchbypincode(void)
{
	person p;
	FILE *fp;
	int count=0,pin;
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter pincode you want to search : ");
	fflush(stdout);
	scanf("%d",&pin);
	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		if(pin==p.pincode)
		{
			print(p);
			count++;
		}
	}
	printf("\n    %d records found",count);
	fclose(fp);
	return ;
}

void searchbymno(void)
{
	person p;
	FILE *fp;
	int count=0;
	char mno[15];
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	printf("\n\t\t\tEnter mobile no you want to search : ");
	fflush(stdout);
	scanf("%s",mno);
	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		if((strcmp(mno,p.mno))==0)
		{
			print(p);
			count++;
		}
	}
	printf("\n    %d records found",count);
	fclose(fp);
	return ;
}


void update()
{
	FILE *fp = fopen(mainfile, "r");
	FILE *fp2 = fopen(temp, "w");
	person p;

	if (fp == NULL || fp2 == NULL)
	{
		printf("\n\t\t\tError opening files");
		return;
	}

	int ano;
	printf("\n\t\t\tEnter Aadhar no to update : ");
	fflush(stdout);
	scanf("%d", &ano);


	printf("\n\t\t\t\t\t\t\t\t  For Update");
	while (fread(&p, sizeof(p), 1, fp))
	{
		if (p.ano == ano)
		{
			int choice;
			printline();
			printf("\t\t\t\t\t\t\t    1. Update by Name");
			printf("\n\t\t\t\t\t\t\t    2. Update by Address");
			printf("\n\t\t\t\t\t\t\t    3. Update by Pincode");
			printf("\n\t\t\t\t\t\t\t    4. Update by Mobile Number");
			printf("\n\t\t\t\t\t\t\t    5. Update Whole Record");
			printline();
			printf("\n\t\t\tEnter Choice Here (1-5): ");
			fflush(stdout);
			scanf("%d", &choice);

			switch (choice)
			{
			case 1:
				cd:printf("\t\t\tEnter name : ");
				fflush(stdout);
				scanf(" %s",p.name);
				char mname[15];
				strcpy(mname,p.name);

				int nlen=strlen(mname);
				for(int i=0;i<nlen;i++)
				{
					if(((mname[i]>=65 && mname[i]<=90) || (mname[i]>=97 && mname[i]<=122))==0)
					{
						printf("\n\t\t\tThe name should be in alphabets\n");
						goto cd;
					}
				}
				break;

			case 2:
				printf("\n\t\t\tEnter Address Here: ");
				fflush(stdout);
				scanf("%s", p.address);
				break;

			case 3:
				e:printf("\n\t\t\tEnter Pincode Here: ");
				fflush(stdout);
				scanf("%d", &p.pincode);

				int c;
				c = p.pincode;
				int num = 0;
				while (c > 0)
				{
					num++;
					c = c / 10;
				}

				if (num != 6)
				{
					printf("\n\t\t\tPlease enter 6 digit pincode\n");
					goto e;
				}
				break;

			case 4:
				hf:printf("\t\t\tEnter mobile no : ");
				fflush(stdout);
				scanf(" %s",p.mno);
				if(strlen(p.mno)!=10)
				{
					lb:
					printf("\n\t\t\tInvalid mobile no\n");
					goto hf;
				}
				char mo[10];
				strcpy(mo,p.mno);
				for(int i=0;i<10;i++)
				{
					if((mo[i]>=48 && mo[i]<=57)==0)
					{
						goto lb;
					}
				}
				break;

			case 5:
				printf("\n\t\t\tEnter Whole Record here:\n");
				ce:printf("\t\t\tEnter name : ");
				fflush(stdout);
				scanf(" %s",p.name);
				char nm[15];
				strcpy(nm,p.name);

				int size=strlen(nm);
				for(int i=0;i<size;i++)
				{
					if(((nm[i]>=65 && nm[i]<=90) || (nm[i]>=97 && nm[i]<=122))==0)
					{
						printf("\n\t\t\tThe name should be in alphabets\n");
						goto ce;
					}
				}

				ad:printf("\t\t\tEnter Birth date in DD-MM-YYYY format : ");
				fflush(stdout);
				scanf(" %d-%d-%d",&p.dob.day,&p.dob.month,&p.dob.year);
				if(p.dob.day>=31 || p.dob.day<=0 || p.dob.month<=0 || p.dob.month>12 || p.dob.year<=0)
				{
					printf("\nInvalid Date\n");
					goto ad;
				}
				else if(p.dob.day<=31 && (p.dob.month==1 || p.dob.month==3 || p.dob.month==5 || p.dob.month==7 || p.dob.month==8 || p.dob.month==10 || p.dob.month==12 ))
				{
					goto eo;
				}
				else if(p.dob.day<=30 && (p.dob.month==4 || p.dob.month==6 || p.dob.month==9 || p.dob.month==11) )
				{
					goto eo;
				}
				else if(p.dob.day<=29 && p.dob.month==2 && p.dob.year%4==0)
				{
					goto eo;
				}
				else if(p.dob.day<=28 && p.dob.month==2 && p.dob.year%4!=0)
				{
					goto eo;
				}
				else
				{
					printf("\n\t\t\tInvalid Date\n");
					goto ad;
				}


				eo:printf("\t\t\tEnter gender : ");
				fflush(stdout);
				scanf(" %s",p.gender);
				char gender[9];
				strcpy(gender,p.gender);
				int n=strlen(gender);
				for(int i=0;i<n;i++)
				{
					if((gender[i]>=65 && gender[i]<=90) || (gender[i]>=97 && gender[i]<=122))
					{
						if(gender[i]>=65 && gender[i]<=90)
						{
							gender[i]=gender[i]+32;
						}
					}
					else
					{
						printf("\n\t\t\tThe Gender should be in alphabets\n");
						goto eo;
					}
				}
				if((strcmp(gender,"female")==0) || (strcmp(gender,"male")==0) || (strcmp(gender,"other")==0))
				{
					goto fe;
				}
				else
				{
					printf("\n\t\t\tInvalid gender\n");
					goto eo;
				}

				fe:printf("\t\t\tEnter issue date DD-MM-YYYY format : ");
				fflush(stdout);
				scanf(" %d-%d-%d",&p.i_date.day,&p.i_date.month,&p.i_date.year);

				if(p.i_date.day>=31 || p.i_date.day<=0 || p.i_date.month<=0 || p.i_date.month>12 || p.i_date.year<=0)
				{
					printf("\nInvalid Date\n");
					goto fe;
				}
				else if(p.i_date.day<=31 && (p.i_date.month==1 || p.i_date.month==3 || p.i_date.month==5 || p.i_date.month==7 || p.i_date.month==8 || p.i_date.month==10 || p.i_date.month==12 ))
				{
					goto he;
				}
				else if(p.i_date.day<=30 && (p.i_date.month==4 || p.i_date.month==6 || p.i_date.month==9 || p.i_date.month==11) )
				{
					goto he;
				}
				else if(p.i_date.day<=29 && p.i_date.month==2 && p.i_date.year%4==0)
				{
					goto he;
				}
				else if(p.i_date.day<=28 && p.i_date.month==2 && p.i_date.year%4!=0)
				{
					goto he;
				}
				else
				{
					printf("\n\t\t\tInvalid Date\n");
					goto fe;
				}

				he:printf("\t\t\tEnter mobile no : ");
				fflush(stdout);
				scanf(" %s",p.mno);
				if(strlen(p.mno)!=10)
				{
					hs:
					printf("\n\t\t\tInvalid mobile no\n");
					goto he;
				}
				char mno[10];
				strcpy(mno,p.mno);
				for(int i=0;i<10;i++)
				{
					if(mno[i]>=48 && mno[i]<=57)
					{
						goto ei;
					}
					else
					{
						goto hs;
					}
				}

				ei: printf("\t\t\tEnter Pincode Here (in Digit): ");
				fflush(stdout);
				scanf("%d", &p.pincode);

				int code;
				code = p.pincode;
				int d = 0;
				while (code > 0)
				{
					d++;
					code = code / 10;
				}

				if (d != 6)
				{
					printf("\n\t\t\tPlease enter 6 digit pincode\n");
					goto ei;
				}


				printf("\t\t\tEnter Address Here: ");
				fflush(stdout);
				scanf("%s", p.address);

				break;



			default:
				printf("\n\t\t\tWrong Choice\n");
			}
			printf("\n    The record is updated");
			printf("\n    The updated record");
			header();
			print(p);
		}


		fwrite(&p, sizeof(p), 1, fp2);
	}

	fclose(fp);
	fclose(fp2);

	fp = fopen(mainfile, "w");
	fp2 = fopen(temp, "r");

	if (fp == NULL || fp2 == NULL)
	{
		printf("\n\t\t\tError opening files");
		return;
	}

	while (fread(&p, sizeof(p), 1, fp2))
	{
		fwrite(&p, sizeof(p), 1, fp);
	}

	fclose(fp);
	fclose(fp2);

	return ;
}


void sortbyidasc(void)
{
    int nrecord = count();
    person *records = (person *)malloc(nrecord * sizeof(person));
    FILE *fp = fopen(mainfile, "r");
    FILE *temp_fp = fopen(temp, "w+");
    if (fp == NULL || temp_fp == NULL)
    {
        printf("\n\t\t\tError in opening file");
        exit(-1);
    }

    for (int i = 0; i < nrecord; i++)
    {
        fread(&records[i], sizeof(person), 1, fp);
        fwrite(&records[i], sizeof(person), 1, temp_fp);
    }
    fclose(fp);

    person temp_record;
    for (int i = 0; i < nrecord - 1; i++)
    {
        for (int j = i + 1; j < nrecord; j++)
        {
            if (records[i].ano > records[j].ano)
            {
                temp_record = records[i];
                records[i] = records[j];
                records[j] = temp_record;
            }
        }
    }

    rewind(temp_fp);
    for (int i = 0; i < nrecord; i++)
    {
        fwrite(&records[i], sizeof(person), 1, temp_fp);
    }

    printf("\n\n    The sorted data by Aadhar number in ascending order : ");
    header();
    for (int i = 0; i < nrecord; i++)
    {
        print(records[i]);
    }

    fclose(temp_fp);
    free(records);
    return;
}

void sortbyiddesc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\n\t\t\tError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].ano < records[j].ano)
			{
				temp_record = records[i];
				records[i] = records[j];
				records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Aadhar number in descending order: ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbynameasc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\n\t\t\tError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (strcmp(records[i].name,records[j].name)>0)
			{
				temp_record = records[i];
				records[i] = records[j];
				records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Name in ascending order : ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);

	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbynamedesc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\n\t\t\tError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (strcmp(records[i].name,records[j].name)<0)
			{
				temp_record = records[i];
				records[i] = records[j];
				records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Name in descending order : ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbydobdesc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\n\t\t\tError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].dob.year < records[j].dob.year ||
			           (records[i].dob.year == records[j].dob.year && records[i].dob.month < records[j].dob.month) ||
			           (records[i].dob.year == records[j].dob.year && records[i].dob.month == records[j].dob.month && records[i].dob.day < records[j].dob.day))
			{

						temp_record = records[i];
						records[i] = records[j];
						records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Birth date by latest to oldest : ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}


void sortbydobasc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\n\t\t\tError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].dob.year > records[j].dob.year ||
			           (records[i].dob.year == records[j].dob.year && records[i].dob.month > records[j].dob.month) ||
			           (records[i].dob.year == records[j].dob.year && records[i].dob.month == records[j].dob.month && records[i].dob.day > records[j].dob.day))
			{

						temp_record = records[i];
						records[i] = records[j];
						records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Birth date by oldest to latest : ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbyidateasc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\nError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].i_date.year > records[j].i_date.year ||
					   (records[i].i_date.year == records[j].i_date.year && records[i].i_date.month > records[j].i_date.month) ||
					   (records[i].i_date.year == records[j].i_date.year && records[i].i_date.month == records[j].i_date.month && records[i].i_date.day > records[j].i_date.day))
			{

						temp_record = records[i];
						records[i] = records[j];
						records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Issue date by oldest to latest : ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbyidatedesc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\nError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].i_date.year < records[j].i_date.year ||
					   (records[i].i_date.year == records[j].i_date.year && records[i].i_date.month < records[j].i_date.month) ||
					   (records[i].i_date.year == records[j].i_date.year && records[i].i_date.month == records[j].i_date.month && records[i].i_date.day < records[j].i_date.day))
			{

						temp_record = records[i];
						records[i] = records[j];
						records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Issue date by latest to oldest : ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbypincodedesc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\n\t\t\tError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].pincode < records[j].pincode)
			{
				temp_record = records[i];
				records[i] = records[j];
				records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Pincode in descending order: ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}

void sortbypincodeasc(void)
{
	int nrecord = count();
	person *records = (person *)malloc(nrecord * sizeof(person));
	FILE *fp = fopen(mainfile, "r");
	FILE *temp_fp = fopen(temp, "w+");
	if (fp == NULL || temp_fp == NULL)
	{
		printf("\nError in opening file");
		exit(-1);
	}

	for (int i = 0; i < nrecord; i++)
	{
		fread(&records[i], sizeof(person), 1, fp);
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}
	fclose(fp);

	person temp_record;
	for (int i = 0; i < nrecord - 1; i++)
	{
		for (int j = i + 1; j < nrecord; j++)
		{
			if (records[i].pincode > records[j].pincode)
			{
				temp_record = records[i];
				records[i] = records[j];
				records[j] = temp_record;
			}
		}
	}

	rewind(temp_fp);
	for (int i = 0; i < nrecord; i++)
	{
		fwrite(&records[i], sizeof(person), 1, temp_fp);
	}

	printf("\n\n    The sorted data by Pincode in ascending order: ");
	header();
	for (int i = 0; i < nrecord; i++)
	{
		print(records[i]);
	}

	fclose(temp_fp);
	free(records);
	return;
}


void delete(void)
{
	 FILE *fp,*fp2;
	 int no,count=0;
	 person p;
	 fp=fopen(mainfile,"r");
	 fp2=fopen(temp,"w");
	 if(fp==NULL ||fp2==NULL)
	 {
		 printf("\n\t\t\tError in opening file");
		 exit(-1);
	 }
	 printf("\n\t\t\tEnter Aadhar no to delete : ");
	 fflush(stdout);
	 scanf("%d",&no);
	 while(fread(&p,sizeof(p),1,fp))
	 {
		 if(p.ano!=no)
		 {
			 count++;
			 fwrite(&p,sizeof(p),1,fp2);
		 }
	 }
	 fclose(fp);
	 fclose(fp2);
	 fp=fopen(mainfile,"w");
	 fp2=fopen(temp,"r");
	 if(fp==NULL ||fp2==NULL)
	 {
		 printf("\n\t\t\tError in opening file");
		 exit(-1);
	 }
	 while(fread(&p,sizeof(p),1,fp2))
	 {
		 fwrite(&p,sizeof(p),1,fp);
	 }
	 fclose(fp);
	 fclose(fp2);
	 return;
}


void sort(void)
{

	printf("\n\t\t\t\t\t\t\t\tFor sorting : ");
	printline();
	printf("\t\t\t\t\t\t   1) Sort by Aadhar no in ascending order");
	printf("\n\t\t\t\t\t\t   2) Sort by Aadhar no in descending order");
	printf("\n\t\t\t\t\t\t   3) Sort by Name in ascending order");
	printf("\n\t\t\t\t\t\t   4) Sort by Name in descending order");
	printf("\n\t\t\t\t\t\t   5) Sort by Birth Date by oldest to latest");
	printf("\n\t\t\t\t\t\t   6) Sort by Birth Date by latest to oldest");
	printf("\n\t\t\t\t\t\t   7) Sort by Issue Date by oldest to latest");
	printf("\n\t\t\t\t\t\t   8) Sort by Issue Date by latest to oldest");
	printf("\n\t\t\t\t\t\t   9) Sort by Pincode in ascending order");
	printf("\n\t\t\t\t\t\t  10) Sort by Pincode in descending order");
	printline();
	int menu;
	ab:printf("\n\n\t\t\tEnter the menu no : ");
	fflush(stdout);
	scanf("%d",&menu);

	switch(menu)
	{
	case 1:
		sortbyidasc();
		break;
	case 2:
		sortbyiddesc();
		break;
	case 3:
		sortbynameasc();
		break;
	case 4:
		sortbynamedesc();
		break;
	case 5:
		sortbydobasc();
		break;
	case 6:
		sortbydobdesc();
		break;
	case 7:
		sortbyidateasc();
		break;
	case 8:
		sortbyidatedesc();
		break;
	case 9:
		sortbypincodeasc();
		break;
	case 10:
		sortbypincodedesc();
		break;
	default:
		printf("\n\t\t\tYou entered wrong menu no : ");
		goto ab;
	}
	return ;
}


void search(void)
{
	printf("\n\t\t\t\t\t\t\t\tFor search : ");
	printline();
	printf("\t\t\t\t\t\t\t   1) Search by Aadhar no ");
	printf("\n\t\t\t\t\t\t\t   2) Search by Name");
	printf("\n\t\t\t\t\t\t\t   3) Search by Birth Date");
	printf("\n\t\t\t\t\t\t\t   4) Search by Gender ");
	printf("\n\t\t\t\t\t\t\t   5) Search by Issue Date");
	printf("\n\t\t\t\t\t\t\t   6) Search by Pincode");
	printf("\n\t\t\t\t\t\t\t   7) Search by Mobile no");
	printline();
	int menu;
	bc:printf("\n\n\t\t\tEnter the menu no : ");
	fflush(stdout);
	scanf("%d",&menu);

	switch(menu)
	{
	case 1:
		searchbyid();
		break;
	case 2:
		searchbyname();
		break;
	case 3:
		searchbydob();
		break;
	case 4:
		searchbygender();
		break;
	case 5:
		searchbyi_date();
		break;
	case 6:
		searchbypincode();
		break;
	case 7:
		searchbymno();
		break;
	default:
		printf("\n\t\t\tYou entered wrong menu no : ");
		goto bc;
	}
	return ;
}


void printmenu()
{
	int ch=0;int record;
	int choice=0;
	while(choice==0)
	{
		printf("\n\n");
		printui();
		printline();
		printf("\t\t\t\t\t\t\t    1. Add Aadhar details\n");
		printf("\t\t\t\t\t\t\t    2. Display Aadhar details \n");
		printf("\t\t\t\t\t\t\t    3. Search Aadhar detail \n");
		printf("\t\t\t\t\t\t\t    4. Update Aadhar detail \n");
		printf("\t\t\t\t\t\t\t    5. Delete Aadhar detail \n");
		printf("\t\t\t\t\t\t\t    6. Sort Aadhar Details \n");
		printf("\t\t\t\t\t\t\t    7. Count the records\n");
		printf("\t\t\t\t\t\t\t    8. Exit ");
		printline();
		printf("\n\t\t\tEnter your choice : ");
		fflush(stdout);
		scanf("%d",&ch);
		switch(ch)
		{

			case 1:
				insert();
				break;
			case 2:
				display();
				break;
			case 3:
				search();
				break;
			case 4:
				update();
				break;
			case 5:
				delete();
				break;
			case 6:
				sort();
				break;
			case 7:
				record=count();
				printf("\n\t\t\t%d records in file ",record);
				break;
			case 8:
				choice=1;
				goto o;
			default:
				printf("\n\t\t\tWrong choice");
		}
	printf("\n\t\t\tDo you want to continue : (0-Yes, 1-No) : ");
	fflush(stdout);
	scanf("%d",&choice);

	}while(choice==0);
	o:
	return ;
}


void printui(void)
{
	printf("\n");
	for(int i=0;i<69;i++)
	{
		printf("*");
	}
	printf("UDIAI");
	for(int i=0;i<69;i++)
	{
		printf("*");
	}
	return ;
}


int count()
 {
	 person p;
	 FILE *fp;
	 int count=0;
	 fp=fopen(mainfile,"r");
	 if(fp==NULL)
	 {
		 printf("\t\t\tError in opening file \n");
		 return 1;
	 }
	 while(fread(&p,sizeof(p),1,fp))
	 {
		 count++;
	 }
	 fclose(fp);
	 return count;
 }

