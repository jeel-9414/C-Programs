/*
 * f1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>

int main()
{
	FILE *fp=NULL;

	fp=fopen("abc.txt","r");

	if(fp==NULL){
		printf("Error");
	}

//	char ch;
	fgetc(fp);
	int pos=ftell(fp);

	printf("%d\n",pos);
//	fseek(fp,8,SEEK_SET);

	printf("%d\n",ftell(fp));

	fclose(fp);
}

