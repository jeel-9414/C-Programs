/*
 * q7.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int isPrime(int );

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	int n;
	printf("enter number here:");
	scanf("%d",&n);

	printf("the number his=%d",isPrime(n));
	return 0;
}

int isPrime(int n)
{
	int i,count=0;

	for(i=1;i<=n;i++){
		if(n%i==0){
			count++;
		}
	}

	if(count==2){
		return 0;
	}else{
		return 1;
	}
}
