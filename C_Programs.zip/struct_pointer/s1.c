/*
 * s1.c
 *
 *  Created on: 8 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

struct student{
	int id;
	char name[20];
	float gpa;
};

int main()
{

	struct student s1={1,"Jeel",8.76};
	struct student *p=&s1;
//	p=&s1;
	printf("Name is=%s",(*p).name);
	return 0;
}

