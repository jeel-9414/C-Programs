/*
 * app.c
 *
 *  Created on: 30 Mar 2025
 *      Author: nikul
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define mainfile "udiai.txt"
#define temp_file "temp.txt"

typedef struct
{
    int d, m, y;
} date;

typedef struct
{
    char name[20];
    int ano;
    date dob;
    char gender[20];
    char mno[20];
    date i_date;
    char address[50];
    int pincode;
} person;
void insert();
void display();
void print();
int count();
void header();
void printui();
void printline();
void search();
void searchbyano();
void searchbygender();
void searchbydob();
void searchbymno();
void searchbyissuedate();
void searchbyname();
void update();
void sortbyanoasc();
void sortbyanodesc();
void sortbygender();
void sortbyname();
void sortbypincode();
void sortbybirthdate();
void sortbyissuedate();
void sort();
void delete();
void printmenu();
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

    printmenu();
    return 0;
}

void print(person p)
{
    header();
//    person p;
    printf("\n    %-15d%-18s%2d-%2d-%-9d%-13s%2d-%2d-%-9d%-13s%-9d%-45s",
           p.ano, p.name, p.dob.d, p.dob.m, p.dob.y,
           p.gender, p.i_date.d, p.i_date.m, p.i_date.y,
           p.mno, p.pincode, p.address);
    return;
}

void header()
{
    printui();
    printf("\n\n");
    printline();
    printf("    %-15s%-18s%-15s%-13s%-15s%-13s%-9s%-45s", "Aadhar No", "Name", "Birth Date", "Gender", "Issue Date", "Mobile No", "Pincode", "Address");
    printf("\n\n");
    printline();
    return;
}

void insert()
{
    FILE *fp = NULL;

    fp = fopen(mainfile, "a+");
    if(fp==NULL){
    	printf("Error in opening the file\n");
    }
    person p;
//    int no;
    printf("Enter name here:");
    scanf("%s",p.name);

a:
    printf("Enter Aadhar number here:");
    scanf("%d", &p.ano);

    int no=p.ano;
    while(fread(&p,sizeof(p),1,fp))
    	{

    if (no == p.ano)
    {
        printf("Please enter diffrent aadhar number %d is already exist\n", no);
        goto a;
    }

    	}
b:
    printf("Enter date of birth here (DD-MM-YYYY):");
    scanf("%d-%d-%d", &p.dob.d, &p.dob.m, &p.dob.y);

    if (p.dob.y > 2100 || p.dob.y < 1900)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (p.dob.m < 1 || p.dob.m > 12)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (p.dob.d < 1 || p.dob.d > 31)
    {
        printf("Invalid Date\n");
        goto b;
    }

    if (p.dob.m == 2)
    {
        if (p.dob.y % 4 == 0 && (p.dob.y != 100 || p.dob.y % 400 == 0))
        {
            if (p.dob.d < 1 || p.dob.d > 28)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
        else
        {
            if (p.dob.d < 1 || p.dob.d > 29)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
    }

    if (p.dob.m == 1 || p.dob.m == 3 || p.dob.m == 5 || p.dob.m == 7 || p.dob.m == 8 || p.dob.m == 10 || p.dob.m == 12)
    {
        if (p.dob.d < 1 || p.dob.d > 31)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    if (p.dob.m == 4 || p.dob.m == 6 || p.dob.m == 9 || p.dob.m == 11)
    {
        if (p.dob.d < 1 || p.dob.d > 30)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    else
    {
        goto c;
    }

c:
    printf("Enter the gender here:");
    scanf("%s",p.gender);

    char gender[10];
    strcpy(gender, p.gender);

    if (strcmp(gender, "female") == 0 || strcmp(gender, "male") == 0 || strcmp(gender, "other") == 0)
    {
        goto d;
    }

    else
    {
        printf("Invalid gender\n");
        goto c;
    }
d:
    printf("Enter Mobile number here:");
    scanf("%s", p.mno);

    char mno[15];
    strcpy(mno, p.mno);
    int i=0;

    if (strlen(p.mno) != 10)
    {
        goto d;
    }

    if (mno[i] >= '0' && mno[i] <= '9')
    {
        goto e;
        i++;
    }

    else
    {
        goto e;
    }

e:
    printf("Enter Issue Date here (DD-MM-YYYY):");
    scanf("%d-%d-%d", &p.i_date.d, &p.i_date.m, &p.i_date.y);

    if (p.i_date.y > 2100 || p.i_date.y < 1900)
    {
        printf("Invalid Date\n");
        goto e;
    }
    if (p.i_date.m < 1 || p.i_date.m > 12)
    {
        printf("Invalid Date\n");
        goto e;
    }
    if (p.i_date.d < 1 || p.i_date.d > 31)
    {
        printf("Invalid Date\n");
        goto e;
    }

    if (p.i_date.m == 2)
    {
        if (p.i_date.y % 4 == 0 && (p.i_date.y != 100 || p.i_date.y % 400 == 0))
        {
            if (p.i_date.d < 1 || p.i_date.d > 28)
            {
                printf("Invalid Date\n");
                goto e;
            }
        }
        else
        {
            if (p.i_date.d < 1 || p.i_date.d > 29)
            {
                printf("Invalid Date\n");
                goto e;
            }
        }
    }

    if (p.i_date.m == 1 || p.i_date.m == 3 || p.i_date.m == 5 || p.i_date.m == 7 || p.i_date.m == 8 || p.i_date.m == 10 || p.i_date.m == 12)
    {
        if (p.i_date.d < 1 || p.i_date.d > 31)
        {
            printf("Invalid Date\n");
            goto e;
        }
    }

    if (p.i_date.m == 4 || p.i_date.m == 6 || p.i_date.m == 9 || p.i_date.m == 11)
    {
        if (p.i_date.d < 1 || p.i_date.d > 30)
        {
            printf("Invalid Date\n");
            goto e;
        }
    }

    else
    {
        goto f;
    }

f:
    printf("Enter address here:");
    scanf("%s",p.address);

    printf("Enter Pincode here:");
    scanf("%d", &p.pincode);

    int digit;
    i = 0;
    digit = p.pincode;
    while (digit > 0)
    {
        i++;
        digit = digit / 10;
    }

    if (i != 6)
    {
        printf("Invalid pincode please enter 6 digits\n");
        goto f;
    }

    fclose(fp);
    return;
}

void display(void)
{
	person p;
	FILE *fp;
	int count=0;
	fp=fopen(mainfile,"r");
	if(fp==NULL)
	{
		printf("\n\t\t\tError in opening");
		exit(-1);
	}
	rewind(fp);
	header();
	while(fread(&p,sizeof(p),1,fp))
	{
		print();
		count++;
	}

	printf("\n    %d records found",count);
	fclose(fp);
	return ;
}


int count()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
    }

    while (fread(&p, sizeof(p), 1, fp))
    {
        count++;
    }

    fclose(fp);
    return count;
}

void printui()
{
    printf("\n");
    for (int i = 0; i < 69; i++)
    {
        printf("*");
    }
    printf("UDIAI");
    for (int i = 0; i < 69; i++)
    {
        printf("*");
    }
    return;
}

void printline()
{
    int i;

    for (i = 1; i <= 100; i++)
    {
        printf("-");
    }
}

void searchbyano()
{
    int ano;
    printf("Enter the aadhar number here you want to search:");
    scanf("%d", &ano);

    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (ano == p.ano)
        {
            print();
            count++;
        }
    }

    printf("%d record found", count);

    if (count == 0)
    {
        printf("No reacord Found from %d aadhar number\n", ano);
    }
    fclose(fp);
}

void searchbygender()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    char gender[50];
    printf("Enter gender of a person to find it's record:\n");
    scanf("%s",gender);

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (strcmp(gender, p.gender) == 0)
        {
            print();
            count++;
        }
    }

    printf("%d record found", count);

    if (count == 0)
    {
        printf("No reacord Found from %s aadhar number\n", gender);
    }

    fclose(fp);
}

void serchbydob()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    date d1;
b:
    printf("Enter date of birth here (DD-MM-YYYY):");
    scanf("%d-%d-%d", &d1.d, &d1.m, &d1.y);

    if (d1.y > 2100 || d1.y < 1900)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (d1.m < 1 || d1.m > 12)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (d1.d < 1 || d1.d > 31)
    {
        printf("Invalid Date\n");
        goto b;
    }

    if (d1.m == 2)
    {
        if (d1.y % 4 == 0 && (d1.y != 100 || d1.y % 400 == 0))
        {
            if (d1.d < 1 || d1.d > 28)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
        else
        {
            if (d1.d < 1 || d1.d > 29)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
    }

    if (d1.m == 1 || d1.m == 3 || d1.m == 5 || d1.m == 7 || d1.m == 8 || d1.m == 10 || d1.m == 12)
    {
        if (d1.d < 1 || d1.d > 31)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    if (d1.m == 4 || d1.m == 6 || d1.m == 9 || d1.m == 11)
    {
        if (d1.d < 1 || d1.d > 30)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (d1.d == p.dob.d && d1.m == p.dob.m && d1.y == p.dob.y)
        {
            print();
            count++;
        }
    }

    printf("%d record found", count);

    if (count == 0)
    {
        printf("No reacord Found from this  %d-%d-%d date\n", d1.d, d1.m, d1.y);
    }

    fclose(fp);
}

void searchbymno()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    char mno[20];
g:
    printf("Enter Mobile Number You Want to search:");
    scanf("%s", mno);

    if (strlen(mno) != 10)
    {
        printf("Enter Valid Mobile Number to search\n");
        goto g;
    }

    int i;

    if (mno[i] >= '0' && mno[i] <= '9')
    {
        goto g;
        i++;
    }

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (strcmp(mno, p.mno) == 0)
        {
            print();
            count++;
        }
    }

    printf("%d record found", count);

    if (count == 0)
    {
        printf("No reacord Found from %s mobile number\n", mno);
    }

    fclose(fp);
}

void searchbyissuedate()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    date d1;
b:
    printf("Enter issue date here to search (DD-MM-YYYY):");
    scanf("%d-%d-%d", &d1.d, &d1.m, &d1.y);

    if (d1.y > 2100 || d1.y < 1900)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (d1.m < 1 || d1.m > 12)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (d1.d < 1 || d1.d > 31)
    {
        printf("Invalid Date\n");
        goto b;
    }

    if (d1.m == 2)
    {
        if (d1.y % 4 == 0 && (d1.y != 100 || d1.y % 400 == 0))
        {
            if (d1.d < 1 || d1.d > 28)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
        else
        {
            if (d1.d < 1 || d1.d > 29)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
    }

    if (d1.m == 1 || d1.m == 3 || d1.m == 5 || d1.m == 7 || d1.m == 8 || d1.m == 10 || d1.m == 12)
    {
        if (d1.d < 1 || d1.d > 31)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    if (d1.m == 4 || d1.m == 6 || d1.m == 9 || d1.m == 11)
    {
        if (d1.d < 1 || d1.d > 30)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (d1.d == p.dob.d && d1.m == p.dob.m && d1.y == p.dob.y)
        {
            print();
            count++;
        }
    }

    printf("%d records found\n", count);

    if (count == 0)
    {
        printf("%d-%d-%d issue date is not in any record\n", d1.d, d1.m, d1.y);
    }

    fclose(fp);
}

void searchbydob()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    date d1;
b:
    printf("Enter birth date here to search (DD-MM-YYYY):");
    scanf("%d-%d-%d", &d1.d, &d1.m, &d1.y);

    if (d1.y > 2100 || d1.y < 1900)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (d1.m < 1 || d1.m > 12)
    {
        printf("Invalid Date\n");
        goto b;
    }
    if (d1.d < 1 || d1.d > 31)
    {
        printf("Invalid Date\n");
        goto b;
    }

    if (d1.m == 2)
    {
        if (d1.y % 4 == 0 && (d1.y != 100 || d1.y % 400 == 0))
        {
            if (d1.d < 1 || d1.d > 28)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
        else
        {
            if (d1.d < 1 || d1.d > 29)
            {
                printf("Invalid Date\n");
                goto b;
            }
        }
    }

    if (d1.m == 1 || d1.m == 3 || d1.m == 5 || d1.m == 7 || d1.m == 8 || d1.m == 10 || d1.m == 12)
    {
        if (d1.d < 1 || d1.d > 31)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    if (d1.m == 4 || d1.m == 6 || d1.m == 9 || d1.m == 11)
    {
        if (d1.d < 1 || d1.d > 30)
        {
            printf("Invalid Date\n");
            goto b;
        }
    }

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (d1.d == p.dob.d && d1.m == p.dob.m && d1.y == p.dob.y)
        {
            print();
            count++;
        }
    }

    printf("%d records found\n", count);

    if (count == 0)
    {
        printf("%d-%d-%d birth date is not in any record\n", d1.d, d1.m, d1.y);
    }

    fclose(fp);
}
void searchbyname()
{
    person p;
    FILE *fp = NULL;
    int count = 0;
    fp = fopen(mainfile, "r");

    if (fp == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    char name[30];
    printf("Enter Name here you want to search:");
    scanf("%s",name);

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (strcmp(name, p.name) == 0)
        {
            print();
            count++;
        }
    }

    printf("%d records found\n", count);

    if (count == 0)
    {
        printf("%s name is not in any record\n", name);
    }

    fclose(fp);
}
void search()
{
    int choice, ch;
    do
    {
        printf("\t\t\t\t\\t\t 1.Search By Aadhar Nunber\n");
        printf("\t\t\t\t\\t\t 2.Search By Gender\n");
        printf("\t\t\t\t\\t\t 3.Search By Birth Date\n");
        printf("\t\t\t\t\t\t\t4.Search By Name\n");
        printf("\t\t\t\t\t\t\t5.Search By Mobile Number\n");
        printf("Enter Choice Here (1-5):");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            searchbyano();
            break;

        case 2:
            searchbygender();
            break;

        case 3:
            searchbydob();
            break;

        case 4:
            searchbyname();
            break;

        case 5:
            searchbymno();
            break;
        default:
            printf("Invalid Choice is entered by user\n");
            break;
        }

        printf("Enter 1 if you want to continue and 0 if you want to exit\n");
        scanf("%d", &ch);
    } while (ch == 1);
}

void update()
{
    person p;
    FILE *fp = NULL;
    FILE *fp1 = NULL;

//    int count = 0;
    fp = fopen(mainfile, "r");
    fp1 = fopen(temp_file, "w");
    if (fp == NULL || fp1 == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    int ano;
    char gender[15];

    printf("Enter Aaddhar Number here for update:");
    scanf("%d", &ano);

    int choice, ch=0;

    while (fread(&p, sizeof(p), 1, fp))
    {
        if (ano == p.ano)
        {
            do
            {
            y:
                printf("\t\t\t 1.Update By Name\n");
                printf("\t\t\t 2.Update By Gender\n");
                printf("\t\t\t 3.Update By Moblie Number\n");
                printf("\t\t\t 4.Update By Address\n");

                printf("Enter Choice Here (1-4):");
                scanf("%d", &choice);

                switch (choice)
                {
                case 1:
                    printf("Enter Name Here:");
                   scanf("%s",p.name);

                    print();
                    break;

                case 3:
                    printf("Enter Gender Here:");
                    scanf("%s",p.gender);

                    if (strcmp(p.gender, "female") == 0 || strcmp(p.gender, "male") == 0 || strcmp(p.gender, "other") == 0)
                    {
                        goto y;
                    }

                    print();
                    break;

                case 4:
                i:
                    printf("Enter Mobile Number Here:");
                    scanf("%s",p.mno);

                    if (strlen(p.mno) != 10)
                    {
                        printf("Please Enter 10 digit Mobile Number\n");
                        goto i;
                    }

                    print();
                    break;

                case 5:
                    printf("Enter Whole Record  Below:\n");
                b:
                    printf("Enter date of birth here (DD-MM-YYYY):");
                    scanf("%d %d %d", &p.dob.d, &p.dob.m, &p.dob.y);

                    if (p.dob.y > 2100 || p.dob.y < 1900)
                    {
                        printf("Invalid Date\n");
                        goto b;
                    }
                    if (p.dob.m < 1 || p.dob.m > 12)
                    {
                        printf("Invalid Date\n");
                        goto b;
                    }
                    if (p.dob.d < 1 || p.dob.d > 31)
                    {
                        printf("Invalid Date\n");
                        goto b;
                    }

                    if (p.dob.m == 2)
                    {
                        if (p.dob.y % 4 == 0 && (p.dob.y != 100 || p.dob.y % 400 == 0))
                        {
                            if (p.dob.d < 1 || p.dob.d > 28)
                            {
                                printf("Invalid Date\n");
                                goto b;
                            }
                        }
                        else
                        {
                            if (p.dob.d < 1 || p.dob.d > 29)
                            {
                                printf("Invalid Date\n");
                                goto b;
                            }
                        }
                    }

                    if (p.dob.m == 1 || p.dob.m == 3 || p.dob.m == 5 || p.dob.m == 7 || p.dob.m == 8 || p.dob.m == 10 || p.dob.m == 12)
                    {
                        if (p.dob.d < 1 || p.dob.d > 31)
                        {
                            printf("Invalid Date\n");
                            goto b;
                        }
                    }

                    if (p.dob.m == 4 || p.dob.m == 6 || p.dob.m == 9 || p.dob.m == 11)
                    {
                        if (p.dob.d < 1 || p.dob.d > 30)
                        {
                            printf("Invalid Date\n");
                            goto b;
                        }
                    }
                    print();

                c:
                    printf("Enter the gender here:");
                    scanf("%s",p.gender);

                    char gender[10];
                    strcpy(gender, p.gender);

                    if (strcmp(gender, "female") == 0 || strcmp(gender, "male") == 0 || strcmp(gender, "other") == 0)
                    {
                        goto d;
                    }

                    else
                    {
                        printf("Invalid gender\n");
                        goto c;
                    }
                d:
                    printf("Enter Mobile number here:");
                    scanf("%s", p.mno);

                    char mno[15];
                    strcpy(mno, p.mno);
                    int i=0;

                    if (strlen(p.mno) != 10)
                    {
                        goto d;
                    }

                    if (mno[i] >= '0' && mno[i] <= '9')
                    {
                        goto e;
                        i++;
                    }

                    else
                    {
                        goto e;
                    }

                e:
                    printf("Enter Issue Date here (DD-MM-YYYY):");
                    scanf("%d %d %d", &p.i_date.d, &p.i_date.m, &p.i_date.y);

                    if (p.i_date.y > 2100 || p.i_date.y < 1900)
                    {
                        printf("Invalid Date\n");
                        goto e;
                    }
                    if (p.i_date.m < 1 || p.i_date.m > 12)
                    {
                        printf("Invalid Date\n");
                        goto e;
                    }
                    if (p.i_date.d < 1 || p.i_date.d > 31)
                    {
                        printf("Invalid Date\n");
                        goto e;
                    }

                    if (p.i_date.m == 2)
                    {
                        if (p.i_date.y % 4 == 0 && (p.i_date.y != 100 || p.i_date.y % 400 == 0))
                        {
                            if (p.i_date.d < 1 || p.i_date.d > 28)
                            {
                                printf("Invalid Date\n");
                                goto e;
                            }
                        }
                        else
                        {
                            if (p.i_date.d < 1 || p.i_date.d > 29)
                            {
                                printf("Invalid Date\n");
                                goto e;
                            }
                        }
                    }

                    if (p.i_date.m == 1 || p.i_date.m == 3 || p.i_date.m == 5 || p.i_date.m == 7 || p.i_date.m == 8 || p.i_date.m == 10 || p.i_date.m == 12)
                    {
                        if (p.i_date.d < 1 || p.i_date.d > 31)
                        {
                            printf("Invalid Date\n");
                            goto e;
                        }
                    }

                    if (p.i_date.m == 4 || p.i_date.m == 6 || p.i_date.m == 9 || p.i_date.m == 11)
                    {
                        if (p.i_date.d < 1 || p.i_date.d > 30)
                        {
                            printf("Invalid Date\n");
                            goto e;
                        }
                    }

                    else
                    {
                        goto f;
                    }

                f:
                    printf("Enter address here:");
                    scanf("%s",p.address);

                    printf("Enter Pincode here:");
                    scanf("%d", &p.pincode);

                    int digit;
                    i = 0;
                    digit = p.pincode;
                    while (digit > 0)
                    {
                        i++;
                        digit = digit / 10;
                    }

                    if (digit != 6)
                    {
                        printf("Invalid pincode please enter 6 digits\n");
                        goto f;
                    }

                    print();
                    fclose(fp);
                    return;

                default:
                    printf("\t\t\t Worng Choice\n");
                    break;
                }

                printf("Enter 1 if you want to continue or 0 if you want to exit:\n");
                scanf("%d",&ch);

                fwrite(&p, sizeof(p), 1, fp1);
            } while (ch == 1);
        }
    }

    fclose(fp);
    fclose(fp1);

    fp = fopen(mainfile, "w");
    fp1 = fopen(temp_file, "r");

    while (fread(&p, sizeof(p), 1, fp1))
    {
        fwrite(&p, sizeof(p), 1, fp);
    }

    fclose(fp);
    fclose(fp1);

    fp = fopen(mainfile, "r");

    while (fread(&p, sizeof(p), 1, fp))
    {
        print();
    }

    fclose(fp);
}

void sortbyanoasc()
{
    FILE *fp = NULL;
    FILE *fp1 = NULL;

    if (fp == NULL || fp1 == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

//    person p;
    person temp;
    int n = count();
    person *ptr = (person *)malloc(n * sizeof(person));

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (ptr[i].ano > ptr[j].ano)
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp1);

    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    header();
    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}

void sortbyanodesc()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("error in opening the file\n");
        return;
    }
    int n = count();
    person *ptr = (person *)malloc(n * sizeof(person));

    person temp;

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (ptr[i].ano < ptr[j].ano)
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp);
    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    header();
    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}

void sortbygender()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    int n = count();

    person *ptr = (person *)malloc(n * sizeof(person));

    person temp;

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (strcmp(ptr[i].gender, ptr[j].gender) > 0)
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp1);

    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}

void sortbyname()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("Error in opening the file\n");
        return;
    }

    int n = count();

    person *ptr = (person *)malloc(n * sizeof(person));

    person temp;

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (strcmp(ptr[i].name, ptr[j].name) > 0)
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp1);

    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}
void sortbypincode()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("error in opening the file\n");
        return;
    }
    int n = count();
    person *ptr = (person *)malloc(n * sizeof(person));

    person temp;

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (ptr[i].pincode < ptr[j].pincode)
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp);
    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    header();
    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}
void sortbybirthdate()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("error in opening the file\n");
        return;
    }
    int n = count();
    person *ptr = (person *)malloc(n * sizeof(person));

    person temp;

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (ptr[i].dob.y > ptr[j].dob.y || (ptr[i].dob.y == ptr[j].dob.y && ptr[i].dob.m > ptr[j].dob.m) || (ptr[i].dob.y == ptr[j].dob.y && ptr[i].dob.m == ptr[j].dob.m && ptr[i].dob.d > ptr[j].dob.d))
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp);
    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    header();
    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}

void sortbyissuedate()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("error in opening the file\n");
        return;
    }
    int n = count();
    person *ptr = (person *)malloc(n * sizeof(person));

    person temp;

    for (int i = 0; i < n; i++)
    {
        fread(&ptr[i], sizeof(person), 1, fp);
        fwrite(&ptr[i], sizeof(person), 1, fp1);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (ptr[i].i_date.y > ptr[j].i_date.y || (ptr[i].i_date.y == ptr[j].i_date.y && ptr[i].i_date.m > ptr[j].i_date.m) || (ptr[i].i_date.y == ptr[j].i_date.y && ptr[i].i_date.m == ptr[j].i_date.m && ptr[i].i_date.d > ptr[j].i_date.d))
            {
                temp = ptr[i];
                ptr[i] = ptr[j];
                ptr[j] = temp;
            }
        }
    }

    rewind(fp);
    for (int i = 0; i < n; i++)
    {
        fwrite(&ptr[i], sizeof(person), 1, fp);
    }

    header();
    for (int i = 0; i < n; i++)
    {
        print(ptr[i]);
    }

    fclose(fp);
    fclose(fp1);
    free(ptr);
}

void sort()
{
    int choice,ch;

    do
    {
        printf("\t\t\t\t 1.Sort By Aaadhar number ascending order\n");
        printf("\t\t\t\t 2.Sort By Aaadhar number descending order\n");
        printf("\t\t\t\t 3.Sort By pincode number ascending order\n");
        printf("\t\t\t\t 4.Sort By Birth Date in ascending order\n");
        printf("\t\t\t\t 5.Sort By Name\n");
        printf("\t\t\t\t 6.Sort By Gneder\n");
        printf("\t\t\t\t 7.Sort By Issue Date\n");

        printf("enter Choice Here:");
        scanf("%d",&choice);

        switch (choice)
        {
        case 1:sortbyanoasc();
            break;

        case 2:sortbyanodesc();
            break;

        case 3:sortbypincode();
            break;

        case 4:sortbybirthdate();
            break;

        case 5:sortbyname();
            break;

        case 6:sortbygender();
            break;

        case 7:sortbyissuedate();
            break;
        default:printf("\t\t\t Wrong Choice\n");
            break;
        }

        printf("Enter 1 if you want to continue or 0 if you want to exit:\n");
        scanf("%d",&ch);
    } while (ch==1);
}

void delete()
{
    FILE *fp = fopen(mainfile, "r");
    FILE *fp1 = fopen(temp_file, "w");

    if (fp == NULL || fp1 == NULL)
    {
        printf("error in opening the file\n");
        return;
    }
    person p;
    int ano;
//    int n=count();
    printf("Enter Aadhar Number Here Which You Want to delete:");
    scanf("%d",&ano);

    while(fread(&p,sizeof(p),1,fp)){
        if (ano!=p.ano)
        {
            fwrite(&p,sizeof(p),1,fp1);
        }
    }

    fclose(fp);
    fclose(fp1);

    fp=fopen(mainfile,"w");
    fp1=fopen(temp_file,"r");

    while(fread(&p,sizeof(p),1,fp1))
    {
        fwrite(&p,sizeof(p),1,fp);
    }

    fclose(fp);
    fclose(fp1);

    fp=fopen(mainfile,"r");

    while(fread(&p,sizeof(p),1,fp))
    {
        print();
    }

    fclose(fp);
}

void printmenu()
{
	int ch;
	int choice;
	do
	{
		printf("\n\n");
		printui();
		printf("\n\n");
		printline();
		printf("\n\n");
		printf("\t\t\t\t\t\t\t    1. Add Aadhar details\n");
		printf("\t\t\t\t\t\t\t    2. Display Aadhar details \n");
		printf("\t\t\t\t\t\t\t    3. Search Aadhar detail \n");
		printf("\t\t\t\t\t\t\t    4. Update Aadhar detail \n");
		printf("\t\t\t\t\t\t\t    5. Delete Aadhar detail \n");
		printf("\t\t\t\t\t\t\t    6. Sort Aadhar Details \n");
		printf("\t\t\t\t\t\t\t    7. Count the records\n");
		printf("\t\t\t\t\t\t\t    8. Exit ");
		printf("\n\n");
		printline();
		printf("\n\n");
		printf("\n\t\t\tEnter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:
			insert();
			break;

		case 2:
			display();
			break;

		case 3:
			search();
			break;

		case 4:
			update();
			break;

		case 5:
			delete();
			break;

		case 6:
			sort();
			break;

		case 7:
			count();
			break;

		case 8:
			return ;
			break;

		default:
			printf("\t\t\t Wrong Choice\n");
            break;
		}
	printf("\n\t\t\tDo you want to continue : (0-Yes, 1-No) : ");
	scanf("%d",&ch);
	}while(ch==0);
	return ;
}


