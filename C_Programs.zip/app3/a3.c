/*
 * a3.c
 *
 *  Created on: 24 Mar 2025
 *      Author: nikul
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define FILENAME "UIDAI"

typedef struct {
	int d, m, y;
} date;

typedef struct {
	int ano;
	char name[50];
	date dob;
	char gender[50];
	char address[50];
	char mno[15];
	date i_date;
	int pincode;
} person;

void printline();
void header();
void insert();
void display();
void delete();
int count();
void search();
void searchbyano();
void searchbyname();
void searchbypincode();
int update();
void sort();
int main() {

	setvbuf(stdout, NULL, _IONBF, 0);

	int choice, ch;
	printf("\n");
	printf("\n");
	printf("\n");
	printf(
			"\t\t\t************************UIDAI***************************\n\n");
	printf("\n");
	printline();
	printf("\n");
	printf("\n");
	printf("\n");

	do {
		printf("\t\t\t\t1.enter Aaddhar-card details:\n");
		printf("\t\t\t\t2.display Aaddah-card details:\n");
		printf("\t\t\t\t3.search From Aaddhar-card details:\n");
		printf("\t\t\t\t4.Update From Aaddhar-card details:\n");
		printf("\t\t\t\t5.Delete Aaddhar-card details:\n");
		printf("\t\t\t\t6.Sort the Aaddhar-card details:\n");
		printf("\t\t\t\t7.count the details of Aaddhar-card holders:\n");
		printf("\t\t\t\t8.Exit:\n");
		printf("\n");
		printf("\n");
		printf("\n");
		printline();
		printf("\n");
		printf("\n");
		printf("enter the choice here(1-7):");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			insert();
			break;

		case 2:
			display();
			break;

		case 3:
			search();
			break;

		case 4:
			update();
			break;

		case 5:
			delete();
			break;

		case 6:
			sort();
			break;

		case 7:
			count();
			printf("Total records in the file is=%d\n", count());
			break;

		case 8:
			exit(1);
			break;

		default:
			printf("Wrong Choice you have entered\n");
		}
		printf("enter 1  if you want to continue or enter 0:");
		scanf("%d", &ch);
	} while (ch == 1);
	return 0;
}

void printline() {
	int i;
	for (i = 0; i < 120; i++) {
		printf("-");
	}
}
void header() {
	printline();
	printf("\n");
	printf("%s\t\t%s\t\t%s\t\t%s\t\t%s\n", "Aadhar-Number", "Name", "Gender",
			"Address", "Pincode");

	printline();
}

void insert() {
	FILE *fp = fopen(FILENAME, "a+");
	person p;

//	temp.ano=p.ano;
	int count = 0;
	if (fp == NULL) {
		printf("error");
	}

	ab: printf("enter the aadhar no:");
	scanf("%d", &p.ano);

	rewind(fp);
	person temp;
	count = 0;

	while (fread(&temp, sizeof(temp), 1, fp) == 1)
		if (temp.ano == p.ano) {
			count++;
			break;
		}

	if (count > 0) {
		printf("Already Exist");
		goto ab;
	}

	printf("enter name here:");
	scanf("%s", p.name);

	printf("enter dob here:");
	scanf("%d %d %d", &p.dob.d, &p.dob.m, &p.dob.y);

	printf("enter gender here:");
	scanf("%s", p.gender);

	printf("enter issue date here:");
	scanf("%d %d %d", &p.i_date.d, &p.i_date.m, &p.i_date.y);

	printf("enter address here:");
	scanf("%s", p.address);

	printf("enter mobile number here:");
	scanf("%s", p.mno);

	printf("enter pincode here:");
	scanf("%d", &p.pincode);

	fwrite(&p, sizeof(p), 1, fp);
	fclose(fp);
}

void display() {
	FILE *fp = fopen(FILENAME, "r");
	int count = 0;
	person p;

	if (fp == NULL) {
		printf("error");
	}

	printf("\n");
	header();
	printf("\n");
	//printf("\n");
	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
		printf("\n%d\t\t\t%s\t\t\t%s\t\t\t%s\t\t%d\n", p.ano, p.name, p.gender,
				p.address, p.pincode);
	}
	printf("%d record diplayed\n", count);
	fclose(fp);
}

void delete() {
	FILE *fp = fopen(FILENAME, "r");
	FILE *fp2 = fopen("temp.dat", "w"); // Use "w" to ensure the file is overwritten
	person p;
	int ano, found = 0;
	int count = 0;
	if (fp == NULL || fp2 == NULL) {
		printf("Error opening file.\n");
		return;
	}

	printf("Enter Aadhar number to delete: ");
	scanf("%d", &ano);

	// Read the original file and write all non-matching records to the temp file
	while (fread(&p, sizeof(p), 1, fp)) {
		if (ano != p.ano) {
			fwrite(&p, sizeof(p), 1, fp2);
		} else {
			found = 1; // Mark that the record to delete was found
		}
	}

	fclose(fp);
	fclose(fp2);

	if (found) {
		// Overwrite the original file with the temp file
		fp = fopen(FILENAME, "w");
		fp2 = fopen("temp.dat", "r");

		if (fp == NULL || fp2 == NULL) {
			printf("Error opening file.\n");
			return;
		}

		while (fread(&p, sizeof(p), 1, fp2)) {
			fwrite(&p, sizeof(p), 1, fp);
		}

		fclose(fp);
		fclose(fp2);

		printf("Record deleted successfully.\n");
	} else {
		printf("No record found with the given Aadhar number.\n");
	}

	// Reopen the file to display all records
	fp = fopen(FILENAME, "r");

	if (fp == NULL) {
		printf("Error opening file.\n");
		return;
	}

	printf("\n");
	header();
	printf("\n");

	rewind(fp);
	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
		printf("\n%d\t\t\t%s\t\t\t%s\t\t\t%s\t\t%d\n", p.ano, p.name, p.gender,
				p.address, p.pincode);
	}

	printf("%d record diplayed\n", count);
	fclose(fp);
}

int count() {
	person p;
	int count = 0;
	FILE *fp = fopen(FILENAME, "r");

	if (fp == NULL) {
		printf("error");
	}

	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
	}

	fclose(fp);
	return count;
}

void search() {
	int choice;
	int ch;
	printf("\n");
	printline();

	do {
		printf("\n\n\t\t\t\t1.Search By Aaddhar-Number\n");
		printf("\t\t\t\t2.Search By Name\n");
		printf("\t\t\t\t3.Search By Pincode:\n\n");

		printline();

		printf("\n\nEnter Choice Here (1-3):");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			searchbyano();
			break;

		case 2:
			searchbyname();
			break;

		case 3:
			searchbypincode();
			break;

		default:
			printf("Wrong Choice you have entered\n");
		}
		printf("\nEnter 1 for continue and 0 for exit:");
		scanf("%d", &ch);
		printf("\n");
		printline();
	} while (ch == 1);

	printline();
}

void searchbyano() {
	FILE *fp = NULL;
	person p;
	int ano;
	fp = fopen(FILENAME, "r");

	if (fp == NULL) {
		printf("error");
	}

	printf("\nEnter Aaddhar-Number Here Which you want to Search:");
	scanf("%d", &ano);

	printf("\n");
	header();
	printf("\n");
	while (fread(&p, sizeof(p), 1, fp)) {
		if (ano == p.ano) {
			printf("\n%d\t\t\t%s\t\t\t%s\t\t\t%s\t\t%d\n", p.ano, p.name,
					p.gender, p.address, p.pincode);
			return;
		}
	}

	printf("Not found any record\n");

	fclose(fp);
}

void searchbyname() {
	char name[50];
	person p;
	FILE *fp = NULL;

	fp = fopen(FILENAME, "r");

	if (fp == NULL) {
		printf("error");
		return;
	}

	printf("\nEnter Name you want to search:");
	scanf("%s", name);

	printf("\n");
	header();
	printf("\n");
	while (fread(&p, sizeof(p), 1, fp)) {
		if (strcmp(name, p.name) == 0) {
			printf("\n%d\t\t\t%s\t\t\t%s\t\t\t%s\t\t%d\n", p.ano, p.name,
					p.gender, p.address, p.pincode);
			return;
		}
	}

	printf("Not found any record\n");

	fclose(fp);
}

void searchbypincode() {
	FILE *fp = NULL;
	person p;
	int pincode;
	fp = fopen(FILENAME, "r");

	if (fp == NULL) {
		printf("error");
	}

	printf("\nEnter Pincode Here Which you want to Search:");
	scanf("%d", &pincode);

	printf("\n");
	header();
	printf("\n");
	while (fread(&p, sizeof(p), 1, fp)) {
		if (pincode == p.ano) {
			printf("\n%d\t\t\t%s\t\t\t%s\t\t\t%s\t\t%d\n", p.ano, p.name,
					p.gender, p.address, p.pincode);
			return;
		}
	}

	printf("Not found any record\n");

	fclose(fp);
}

int update() {
	int count = 0;
	FILE *fp = fopen(FILENAME, "r");
	FILE *fp2 = fopen("temp.dat", "w");
	person p;

	if (fp == NULL || fp2 == NULL) {
		printf("Error opening files.\n");
		return;
	}

	int ano;
	printf("Enter Aadhar number here: ");
	scanf("%d", &ano);

	printline();

	while (fread(&p, sizeof(p), 1, fp)) {
		if (p.ano == ano) {
			int choice, ch;
			do {
				printf("\n1. Update by Name\n");
				printf("2. Update by Address\n");
				printf("3. Update by Pincode\n");
				printf("4.Update by Mobile Number\n");
				printf("5. Update Whole Record\n");
				printline();
				printf("Enter Choice Here (1-5): ");
				scanf("%d", &choice);

				switch (choice) {
				case 1:
					printf("Enter Name Here: ");
					scanf("%s", p.name);
					break;

				case 2:
					printf("Enter Address Here: ");
					scanf("%s", p.address);
					break;

				case 3:
					printf("Enter Pincode Here: ");
					scanf("%d", &p.pincode);

					int c;
					c = p.pincode;
					int num = 0;
					while (c > 0) {
						num++;
						c = c / 10;
					}

					if (num != 6) {
						printf("Please enter 6 digit pincode\n");
						goto e;
					}

					break;
				case 4:
					printf("enter Mobile Number Here:");
					scanf("%s", p.mno);

					int a=0;

					while (p.mno[a] != '\0') {
						a++;
					}

					if (a != 10) {
						printf("please enter 10 digit mobile number\n");
						goto d;
					}

					break;
				case 5:
					printf("Enter Whole Record here:\n");

					ab: printf("\nEnter the Aadhar No: ");
					scanf("%d", &p.ano);

					rewind(fp);
					person temp;
					count = 0;

					while (fread(&temp, sizeof(temp), 1, fp)) {
						if (temp.ano == p.ano) {
							count++;
							break;
						}
					}

					if (count > 0) {
						printf("Already Exists.\n");
						goto ab;
					}

					printf("\nEnter Name Here: ");
					scanf("%s", p.name);

					printf("enter dob here:");
					scanf("%d %d %d", &p.dob.d, &p.dob.m, &p.dob.y);

					if (p.dob.y < 1900 || p.dob.y > 2100) {
						printf(
								"Invalid year for Date of Birth. Please try again.\n");
						return 1;
					}
					if (p.dob.m < 1 || p.dob.m > 12) {
						printf(
								"Invalid month for Date of Birth. Please try again.\n");
						return 1;
					}

					if (p.dob.d < 1 || p.dob.d > 31) {
						printf(
								"Invalid day for Date of Birth. Please try again.\n");
						return 1;
					}

					if (p.dob.m == 2) {
						if ((p.dob.y % 4 == 0
								&& (p.dob.y % 100 != 0 || p.dob.y % 400 == 0))) {
							if (p.dob.d > 29) {
								printf(
										"Invalid day for February in a leap year. Please try again.\n");
								return 1;
							}
						} else {
							if (p.dob.d > 28) {
								printf(
										"Invalid day for February. Please try again.\n");
								return 1;
							}
						}
					}

					if ((p.dob.m == 4 || p.dob.m == 6 || p.dob.m == 9
							|| p.dob.m == 11) && p.dob.d > 30) {
						printf(
								"Invalid day for the selected month. Please try again.\n");
						return 1;
					}

					if (p.i_date.y < 1900 || p.i_date.y > 2100) {
						printf(
								"Invalid year for Issue Date. Please try again.\n");
						return 1;
					}
					if (p.i_date.m < 1 || p.i_date.m > 12) {
						printf(
								"Invalid month for Issue Date. Please try again.\n");
						return 1;
					}
					if (p.i_date.d < 1 || p.i_date.d > 31) {
						printf(
								"Invalid day for Issue Date. Please try again.\n");
						return 1;
					}

					if (p.i_date.m == 2) {
						if ((p.i_date.y % 4 == 0
								&& (p.i_date.y % 100 != 0
										|| p.i_date.y % 400 == 0))) {
							if (p.i_date.d > 29) {
								printf(
										"Invalid day for February in a leap year. Please try again.\n");
								return 1;
							}
						} else {
							if (p.i_date.d > 28) {
								printf(
										"Invalid day for February. Please try again.\n");
								return 1;
							}
						}
					}

					if ((p.i_date.m == 4 || p.i_date.m == 6 || p.i_date.m == 9
							|| p.i_date.m == 11) && p.i_date.d > 30) {
						printf(
								"Invalid day for the selected month. Please try again.\n");
						return 1;
					}

					printf("\nEnter Gender Here: ");
					scanf("%s", p.gender);

					printf("enter issue date here:");
					scanf("%d %d %d", &p.i_date.d, &p.i_date.m, &p.i_date.y);

					if (p.i_date.y < 1900 || p.i_date.y > 2100) {
						printf(
								"Invalid year for Issue Date. Please try again.\n");
						return 1;
					}

					if (p.i_date.m < 1 || p.i_date.m > 12) {
						printf(
								"Invalid month for Issue Date. Please try again.\n");
						return 1;
					}

					if (p.i_date.d < 1 || p.i_date.d > 31) {
						printf(
								"Invalid day for Issue Date. Please try again.\n");
						return 1;
					}

					// Adjust for February and leap year
					if (p.i_date.m == 2) {
						if ((p.i_date.y % 4 == 0
								&& (p.i_date.y % 100 != 0
										|| p.i_date.y % 400 == 0))) {
							if (p.i_date.d > 29) {
								printf(
										"Invalid day for February in a leap year. Please try again.\n");
								return 1;
							}
						} else {
							if (p.i_date.d > 28) {
								printf(
										"Invalid day for February. Please try again.\n");
								return 1;
							}
						}
					}

					if ((p.i_date.m == 4 || p.i_date.m == 6 || p.i_date.m == 9
							|| p.i_date.m == 11) && p.i_date.d > 30) {
						printf(
								"Invalid day for the selected month. Please try again.\n");
						return 1;
					}

					printf("\nEnter Address Here: ");
					scanf("%s", p.address);

					d: printf("enter Mobile Number Here:");
					scanf("%s", p.mno);

					a=0;

					while (p.mno[a] != '\0') {
						a++;
					}

					if (a != 10) {
						printf("please enter 10 digit mobile number\n");
						goto d;
					}
					e: printf("\nEnter Pincode Here: ");
					scanf("%d", &p.pincode);

					int code;
					code = p.pincode;
					int d = 0;
					while (code > 0) {
						d++;
						code = code / 10;
					}

					if (d != 6) {
						printf("Please enter 6 digit pincode\n");
						goto e;
					}

					break;

				default:
					printf("Wrong Choice\n");
				}

				printf("Enter 1 to continue or 0 to exit: ");
				scanf("%d", &ch);
			} while (ch == 1);
		}

		fwrite(&p, sizeof(p), 1, fp2);
	}

	fclose(fp);
	fclose(fp2);

	fp = fopen(FILENAME, "w");
	fp2 = fopen("temp.dat", "r");

	if (fp == NULL || fp2 == NULL) {
		printf("Error opening files.\n");
		return;
	}

	while (fread(&p, sizeof(p), 1, fp2)) {
		fwrite(&p, sizeof(p), 1, fp);
	}

	fclose(fp);
	fclose(fp2);

	fp = fopen(FILENAME, "r");
	if (fp == NULL) {
		printf("Error opening file.\n");
		return;
	}

	printf("\nUpdated Records:\n");
	header();

	while (fread(&p, sizeof(p), 1, fp)) {
		printf("\n%d\t\t%s\t\t%d-%d-%d\t\t%s\t\t%s\t\t%d-%d-%d\t\t%d\n", p.ano,
				p.name, p.dob.d, p.dob.m, p.dob.y, p.gender, p.address,
				p.i_date.d, p.i_date.m, p.i_date.y, p.pincode);
	}

	fclose(fp);
	return 0;
}

void sort() {
	person temp;
	int nrecord = count(); // Get the total number of records
	person *per = malloc(nrecord * sizeof(person)); // Dynamic memory allocation
	FILE *fp = fopen(FILENAME, "r");
	FILE *fp1 = fopen("temp.dat", "w");

	if (fp == NULL || fp1 == NULL) {
		printf("Error opening files.\n");
		return;
	}

	// Reading records into memory
	int i = 0;
	while (fread(&per[i], sizeof(per[i]), 1, fp)) {
		i++;
	}

	// Sorting the records by 'ano' (ascending order)
	for (int i = 0; i < nrecord - 1; i++) {
		for (int j = i + 1; j < nrecord; j++) {
			if (per[i].ano > per[j].ano) {
				temp = per[i];
				per[i] = per[j];
				per[j] = temp;
			}
		}
	}

	// Writing sorted records to the temporary file
	for (int i = 0; i < nrecord; i++) {
		fwrite(&per[i], sizeof(per[i]), 1, fp1);
	}

	fclose(fp);
	fclose(fp1);

	// Replacing the original file with the sorted records
	fp = fopen(FILENAME, "w");
	fp1 = fopen("temp.dat", "r");

	if (fp == NULL || fp1 == NULL) {
		printf("Error opening files.\n");
		return;
	}

	person p;
	while (fread(&p, sizeof(p), 1, fp1)) {
		fwrite(&p, sizeof(p), 1, fp);
	}

	fclose(fp);
	fclose(fp1);

	// Displaying sorted records
	fp = fopen(FILENAME, "r");
	if (fp == NULL) {
		printf("Error opening file.\n");
		return;
	}

	printf("\nSorted Records:\n");
	header();

	while (fread(&p, sizeof(p), 1, fp)) {
		printf("\n%d\t\t%s\t\t%s\t\t%s\t\t%d\n", p.ano, p.name, p.gender,
				p.address, p.pincode);
	}

	printf("\n%d records displayed.\n", nrecord);

	fclose(fp);
	free(per);
}
