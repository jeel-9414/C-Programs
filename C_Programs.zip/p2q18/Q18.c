/*
 * Q18.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc!=3){
		printf("error:not match");
	}
	else{
		FILE *fp=fopen(argv[1],"r");
		FILE *fp2=fopen(argv[2],"w");

		char ch;
		while(fread(&ch,sizeof(ch),1,fp)){
			fwrite(&ch,sizeof(ch),1,fp2);
		}

		fclose(fp);
		fclose(fp2);
	}
}

