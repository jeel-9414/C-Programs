/*
 * q22.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */

#include<stdio.h>

int main(int argc,char *argv[])
{
	if(argc<2 || argc > 12){
		printf("error");
	}

	FILE *fp=fopen(argv[1],"r");
	int i;
	int n;
	n=argc-1;
	int c[argc-1];
	for(i=1;i<=n;i++)
	{
		c[i-1]=atoi(argv[i]);
	}

	int temp,j;

	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if(c[i]>c[j])
			{
				temp=c[i];
				c[i]=c[j];
				c[j]=temp;
			}
		}
	}

	for(i=0;i<n;i++){
		printf("%d\t",c[i]);
	}

	fclose(fp);
}
