/*
 * leap.c
 *
 *  Created on: 10 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>
int year(int);

int main()
{
	int n;
	printf("Enter year here:");
	scanf("%d",&n);

	printf("The year is leap(1) or not(0):%d\n",year(n));
	return 0;
}

int year(int n){
	if((n%400==0)||(n%4==0 && n%100!=0)){
		return 1;
	}else{
		return 0;
	}
}
