/*
 * fact.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int fact(int );
int fibo(int);
int mul(int  ,int);
int add(int );
int digit(int );
int pow(int ,int );
int main()
{
	int n,m;
	printf("n:");
	scanf("%d %d",&n,&m);

//	printf("%d",mul(n,m));
//	for(int i=0;i<n;i++)
//	printf("%d\t",fibo(i));
//	printf("%d",fact(n));

//    printf("add=%d",add(n));

	printf("power=%d",pow(n,m));
	return 0;
}
/*
int fact(int n)
{
	if(n==1){
		return 1;
	}else{
		return n*fact(n-1);
	}
}*/

/*int fibo(int n)
{
	if(n==0)
	{
		return 0;
	}
	if(n==1)
	{
		return 1;
	}
	else{
		return fibo(n-1)+fibo(n-2);
	}
}*/


/*
int mul(int n,int m)
{
	if(m==0)
	{
		return 0;
	}else{
		return n+mul(n,m-1);
	}
}
*/

/*int add(int n)
{
	if(n==0){
		return 0;
	}else{
		return  n+add(n-1);
	}
}*/

/*

int digit(int n)
{
	int count=0;

	while(n>0){
		n=n/10;
		count++;
	}

	return count++;
}
*/

int pow(int n,int m)
{
	if(m==0){
		return 1;
	}else{
		return n*pow(n,m-1);
	}
}
