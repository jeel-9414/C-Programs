/*
 * Q1.c
 *
 *  Created on: 19 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
//Q.1)
//     Write a C program for a stationary inventory system. The program should:

//Insert data for stationary items (name, price, and quantity).
//
//Display the stored data.
//
//Sort the data by price in ascending order.
//
//Update the details of an existing item (e.g., change the price or quantity).

struct stationary{
	int p_id;
	char name[30];
	int quantity;
	int price;
};

void header();
void printline();
void insert();
void display();
void sort();
void update();
int count();
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);
    insert();
    display();
    sort();
    update();
	return 0;
}

void insert()
{
	struct stationary s;

	FILE *fp=fopen("abc.txt","a");

	if(fp==NULL){
		printf("Error");
	}

	printf("Enter Product id:");
	scanf("%d",&s.p_id);


	printf("Enter Name Here:");
	scanf("%s",s.name);


	printf("Enter Quantity here:");
	scanf("%d",&s.quantity);

	printf("Enter Price here:");
	scanf("%d",&s.price);

	fwrite(&s,sizeof(s),1,fp);

	fclose(fp);
}

void header()
{
	printline();
	printf("\n");
	printf("%-25s %-25s %-25s %-25s","Person Id","Name","Quantity","Price");
	printf("\n");
	printline();
	printf("\n");
}
void printline()
{
	int i;

	for(i=0;i<100;i++){
		printf("-");
	}
}
void display()
{
	struct stationary s;

	FILE *fp=fopen("abc.txt","r");

	if(fp==NULL){
		printf("Error");
	}

	printf("\t\t\t\t\tThe Details of students:\n\n");

	header();

	while(fread(&s,sizeof(s),1,fp)){
		printf("\n%-25d %-28s %-24d %-26d",s.p_id,s.name,s.quantity,s.price);
	}

	fclose(fp);
}

int count()
{
	struct stationary p;
		 FILE *fp;
		 int count=0;
		 fp=fopen("abc.txt","r");
		 if(fp==NULL)
		 {
			 printf("\t\t\tError in opening file \n");
		 }
		 while(fread(&p,sizeof(p),1,fp))
		 {
			 count++;
		 }
		 fclose(fp);
		 return count;
}

void sort()
{

    int n=count();

	struct stationary *ptr=(struct stationary *)malloc(n*sizeof(struct stationary));

	FILE *fp=fopen("abc.txt","r");
    FILE *fp1=fopen("temp.txt","w+");

	if(fp==NULL || fp1==NULL){
		printf("Error");
	}

    for(int i=0;i<n;i++){
    	fread(&ptr[i],sizeof(struct stationary),1,fp);
    	fwrite(&ptr[i],sizeof(struct stationary),1,fp1);
    }

    struct stationary temp;

    for(int i=0;i<n;i++){
    	for(int j=i+1;j<n;j++){
    		if(ptr[i].price > ptr[j].price) {
    		    temp = ptr[i];
    		    ptr[i] = ptr[j];
    		    ptr[j] = temp;
    		}
    	}
    }

    rewind(fp1);

    for(int i=0;i<n;i++){
    	fwrite(&ptr[i],sizeof(struct stationary),1,fp);
    }

    rewind(fp);
    printf("\n\n    The sorted data by Name in ascending order : \n\n");
    header();

    for (int i = 0; i < n; i++) {
        printf("\n%-25d %-28s %-24d %-26d", ptr[i].p_id, ptr[i].name, ptr[i].quantity, ptr[i].price);
    }


    free(ptr);
    fclose(fp);

}

void update()
{
	struct stationary s;

	FILE *fp=fopen("abc.txt","r");
	FILE *fp1 = fopen("temp.txt", "w");

	if(fp==NULL || fp1==NULL){
		printf("Error");
	}

	int p_id;

	printf("Enter Person Id here:");
	scanf("%d",&p_id);

	int quantity;
	printf("Enter the new quantity here:");
    scanf("%d",&quantity);

    while(fread(&s,sizeof(s),1,fp)){
    	if(s.p_id == p_id){
    		s.quantity=quantity;
    	}
         fwrite(&s,sizeof(struct stationary),1,fp1);
    }


    fclose(fp);
    fclose(fp1);

    fp=fopen("abc.txt","w");
    fp1 = fopen("temp.txt", "r");

    if(fp==NULL || fp1==NULL){
    	printf("Error");
    }

    while(fread(&s,sizeof(struct stationary),1,fp1)){
    	fwrite(&s,sizeof(struct stationary),1,fp);
    }

    fclose(fp);
    fclose(fp1);

    fp=fopen("abc.txt","r");


    if(fp==NULL){
        printf("Error");
    }

        printf("\nStatinary Details Here:\n");
        header();

    while(fread(&s,sizeof(s),1,fp)){
    	printf("\n%-25d %-28s %-24d %-26d",s.p_id,s.name,s.quantity,s.price);
    }
}
