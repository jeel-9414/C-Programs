/*
 * 1.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#define Mugdha
int main()
{

#ifdef Linux
	printf("Linux command will be executed\n");

#else

#ifdef WinDows
	printf("Windows Command will be executed\n");

#else

#ifdef Unix
	printf("Unix command will be executed\n");

#ifdef Mac
	printf("Mac Command Will be executed\n");

#else
	printf("Android Command Will be executed\n");
#endif
#endif
#endif
#endif
#ifdef Jeel
	printf("Hey!!\n");
#endif

#ifndef Mugdha
	printf("Pranbir Or Kishdha:Krishdha\n");
#endif

	return 0;
}

