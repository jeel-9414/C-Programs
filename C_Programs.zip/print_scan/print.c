/*
 * print.c
 *
 *  Created on: 24 Mar 2025
 *      Author: nikul
 */
/*
#include<stdio.h>

int main()
{
	char name[20];
	printf("Enter your name: ");
	fflush(stdout); // Forces the output to appear in the console
	scanf("%s", name);

}
*/
#include <stdio.h>

void sum(int a, int b) {
    printf("Sum is: %d\n", a + b);
}

int main() {
    // Disable buffering for stdout
    setvbuf(stdout, NULL, _IONBF, 0);

    int num1, num2;

    printf("Enter first number: ");
    scanf("%d", &num1);

    printf("Enter second number: ");
    scanf("%d", &num2);

    sum(num1, num2);

    return 0;
}
