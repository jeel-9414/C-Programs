/*
 * q9.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

void fact(int );

int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	int n;
	printf("enter number here:");
	scanf("%d",&n);

	printf("the factorial %d:",n);
	fact(n);
	return 0;
}

void fact(int n){
	int i;

	for(i=1;i<=n;i++){
		if(n%i==0){
			printf("%d\t",i);
		}
	}
}
