/*

 * Q26.c
 *
 *  Created on: 23 Mar 2025
 *      Author: nikul
*/
#include<stdio.h>
#include<stdlib.h>
typedef struct {
	char name[50];
	char branch[50];
	int account;
	char bname[50];
	int openyear;
	int balance;
} bank;

typedef struct {
	char name[30];
	char address[50];
	int age;
	char email[40];
} student;

typedef struct {
	char uni_name[50];
	char degree_name[50];
	int duration;
	int addmissionyear;
} university;
void read();
void write();
void merge();
void display_all();
int main() {
	setvbuf(stdout, NULL, _IONBF, 0);

	write();
	read();
	merge();
	display_all();
	return 0;
}

void write() {
	student s;
	FILE *fp = NULL;
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;
	fp = fopen("student_info.txt", "a+");

	if (fp == NULL) {
		printf("error");
	}

	printf("enter student name,address,age,email:");
	scanf("%s %s %d %s", s.name, s.address, &s.age, s.email);
	fprintf(fp,"%s %s %d %s", s.name, s.address, s.age, s.email);

	fclose(fp);


	fp1 = fopen("bank_info.txt", "a+");

	if (fp1 == NULL) {
		printf("error");
	}

	bank b;

	printf("enter bank details for that student name,account-no,name,branch,openning-year,balance:");
	scanf("%s %d %s %s %d %d", b.name,&b.account, b.bname, b.branch, &b.openyear,&b.balance);
    fprintf(fp1,"%s %d %s %s %d %d", b.name,b.account, b.bname, b.branch, b.openyear,b.balance);
	fclose(fp1);

	fp2 = fopen("university_info.txt", "a+");

	if (fp2 == NULL) {
		printf("error");
	}

	university u;

	printf("Enter university details for the student who have enrolled:\n");
	printf("enter details like university name,degree,duration,admission year:");
	scanf("%s %s %d %d", u.uni_name, u.degree_name, &u.duration,&u.addmissionyear);
	fprintf(fp2,"%s %s %d %d", u.uni_name, u.degree_name, u.duration,u.addmissionyear);
	fclose(fp2);
}

void read() {
	FILE *fp = NULL;
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;

	fp = fopen("student_info.txt", "r+");

	if (fp == NULL) {
		printf("error");
	}

	student s;

	rewind(fp);

	printf("student name,address,age,email:\n");
	while (fscanf(fp, "%s %s %d %s", s.name, s.address, &s.age, s.email) ==4) {
		printf("%s\t\t%s\t\t%d\t\t%s\n", s.name, s.address, s.age, s.email);
	}
	fclose(fp);


	fp1 = fopen("bank_info.txt", "r+");

	if (fp1 == NULL) {
		printf("error");
	}

	bank b;

	rewind(fp1);
	printf(
			"bank details for that student account-no,name,branch,openning-year,balance:\n");
	while (fscanf(fp1, "%s %d %s %s %d %d",b.name, &b.account, b.name, b.branch,&b.openyear, &b.balance) ==6) {
		printf("%s\t\t%d\t\t%s\t\t%s\t\t%d\t\t%d\n",b.name, b.account, b.name, b.branch,
				b.openyear, b.balance);
	}
	fclose(fp1);

	fp2 = fopen("university_info.txt", "r+");

	if (fp2 == NULL) {
		printf("error");
	}

	university u;

	rewind(fp2);
	printf("university details for the student who have enrolled:\n");
	printf("university name,degree,duration,admission year:\n");
	while (fscanf(fp2,"%s %s %d %d", u.uni_name, u.degree_name, &u.duration,
			&u.addmissionyear) ==4) {
		printf("%s\t\t%s\t\t%d\t\t%d\n", u.uni_name, u.degree_name, u.duration,
				u.addmissionyear);
	}

	fclose(fp2);
}


void merge()
{
	FILE *fp=NULL;
	FILE *fp1=NULL;
	FILE *fp2=NULL;
	FILE *fp3=NULL;

	student s;
	bank b;
	university u;
	fp3=fopen("sdetails.txt","a+");
	fp=fopen("student_info.txt","a+");
	fp1=fopen("bank_info.txt","a+");
	fp2=fopen("university_info.txt","a+");
	if(fp==NULL || fp1==NULL || fp2==NULL || fp3==NULL){
		printf("error");
	}

	while(fscanf(fp, "%s %s %d %s", s.name, s.address, &s.age, s.email) ==4){
		fprintf(fp3,"%s %s %d %s\n", s.name, s.address, &s.age, s.email);
	}

	while(fscanf(fp1, "%s %d %s %s %d %d", b.name,&b.account, b.name, b.branch,
			&b.openyear, &b.balance) ==6){
		fprintf(fp3,"%s %d %s %s %d %d\n",b.name,b.account, b.name, b.branch,
			b.openyear, b.balance);
	}

	while(fscanf(fp2,"%s %s %d %d", u.uni_name, u.degree_name, &u.duration,
			&u.addmissionyear)==4){
		fprintf(fp3,"%s\t\t%s\t\t%d\t\t%d\n", u.uni_name, u.degree_name, u.duration,
				u.addmissionyear);
	}
}


/*
void display_all()
{
	FILE *fp=NULL;
	student s;
	bank b;
	university u;
	fp=fopen("sdetails.txt","r");

	printf("All The Details Of the student:\n");
	while(fscanf(fp,"%s %s %d %s",s.name,s.address,s.age,s.email)==4){
		printf("%s\t\t%s\t\t%d\t\t%s\n", s.name, s.address, s.age, s.email);
	}

	while (fscanf(fp, "%s %d %s %s %d %d", b.name,&b.account, b.name, b.branch,
				&b.openyear, &b.balance) ==6) {
			printf("%s\t\t%d\t\t%s\t\t%s\t\t%d\t\t%d\n",b.name,b.account, b.name, b.branch,
					b.openyear, b.balance);
		}


	while (fscanf(fp,"%s %s %d %d", u.uni_name, u.degree_name, &u.duration,
				&u.addmissionyear) ==4) {
			printf("%s\t\t%s\t\t%d\t\t%d\n", u.uni_name, u.degree_name, u.duration,
					u.addmissionyear);
		}

	fclose(fp);
}
*/
void display_all() {
    FILE *fp = NULL;
    fp = fopen("sdetails.txt", "r");

    if (fp == NULL) {
        printf("Error: Could not open the file.\n");
        return;
    }

    printf("All Details of the Student:\n\n");

    char line[256]; // Buffer to read each line
    while (fread(line,sizeof(line),1,fp)) {
        printf("%s", line); // Print each line from the file
    }

    fclose(fp);
}

