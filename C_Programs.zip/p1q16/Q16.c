/*
 * Q16.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

void input(int r,int c,int a[r][c]);
void print(int r,int c,int a[r][c]);
int isPrime(int r);
int count(int r,int c,int a[r][c]);
void sort(int r,int c,int a[r][c]);
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	int a[100][100],r,c;
	printf("enter r and c:");
	scanf("%d %d",&r,&c);

	input(r,c,a);
//    isPrime(a);
//    printf("total prime numbers are=%d",count(r,c,a));

	sort(r,c,a);
	print(r,c,a);
	return 0;
}

void input(int r,int c,int a[r][c])
{
	int i,j;

	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			scanf("%d",&a[i][j]);
		}
	}
}

int isPrime(int num) {
	int co=0;
    if (num <= 2){
    	return 0;
    }

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
        	{
        	    co++;
        	}
    }

    if(co==2){
    	return 1;
    }else{
    	return 0;
    }
}

int count(int r,int c,int a[r][c])
{
	int co;
	int i,j;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			if(isPrime(a[i][j])){
				co++;
			}
		}
	}

	return co;
}

void sort(int r,int c,int a[r][c])
{
	int i,j,d[r*c],k,temp;

	k=0;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		    d[k]=a[i][j];
		    k++;
		}
	}

	for(i=0;i<k;i++){
		for(j=0;j<k;j++){
		if(d[i]>d[j]){
			temp=d[i];
			d[i]=d[j];
			d[j]=temp;
		}
		}
	}

	k=0;
		for(i=0;i<r;i++){
			for(j=0;j<c;j++){
			    a[i][j]=d[k];
			    k++;
			}
		}
}

void print(int r,int c,int a[r][c])
{
	int i,j;

		for(i=0;i<r;i++){
			for(j=0;j<c;j++){
				printf("%d\t",a[i][j]);
			}
			printf("\n");
		}
}
