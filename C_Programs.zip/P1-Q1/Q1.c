/*
 * Q1.c
 *
 *  Created on: 22 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct {
	char name[50];
	int pop;
	float litlvl;
} census;

void input();
void print(census);
void sort(census);
int count();
void sortalp(census);
void sortlvl(census);
int main() {
	census c1;
	setvbuf(stdout, NULL, _IONBF, 0);
	input();
	print(c1);
	sort(c1);
	sortalp(c1);
	sortlvl(c1);
	return 0;
}

void input() {
	census c1;

	FILE *fp = fopen("census.txt", "a");

	if (fp == NULL) {
		printf("Error:File Dosen't opening\n");
		exit(0);
	}

	printf("Enter City Name Here:");
	scanf("%s", c1.name);

	printf("Enter Population Here:");
	scanf("%d", &c1.pop);

	printf("Enter Literacy Level:");
	scanf("%f", &c1.litlvl);

	fwrite(&c1, sizeof(census), 1, fp);

	fclose(fp);
}

void print(census c1) {

	FILE *fp = fopen("census.txt", "r");

	if (fp == NULL) {
		printf("Error:File Dosen't opening\n");
		exit(0);
	}

	printf("\nThe Details of Census city Here:\n");

	while (fread(&c1, sizeof(c1), 1, fp)) {
		printf("%s %d %f\n", c1.name, c1.pop, c1.litlvl);
	}
	fclose(fp);
}

int count() {
	census p;
	FILE *fp;
	int count = 0;
	fp = fopen("census.txt", "r");
	if (fp == NULL) {
		printf("\t\t\tError in opening file \n");
		return 1;
	}
	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
	}
	fclose(fp);
	return count;
}
void sort(census temp) {
	FILE *fp = fopen("census.txt", "r");

	census *c;
	int n = count();

	c = (census*) malloc(n * sizeof(census));

	int i = 0;
	while (fread(c + i, sizeof(census), 1, fp)) {
		i++;
	}

	for (int i = 0; i < n; i++) {
		for (int j = i + 1; j < n; j++) {
			if ((c + i)->pop < (c + j)->pop) {
				temp = *(c + i);
				*(c + i) = *(c + j);
				*(c + j) = temp;
			}
		}
	}

	printf("\n");

	printf("sorted Data\n");
	for (int i = 0; i < n; i++) {
		printf("%s %d  %f\n", (c + i)->name, (c + i)->pop, (c + i)->litlvl);
	}

	free(c);
	fclose(fp);
}

void sortalp(census temp) {

	census *c;
	FILE *fp = fopen("census.txt", "r");

	if (fp == NULL) {
		printf("NULL");
		exit(0);
	}

	int n = count();

	c = (census*) malloc(n * sizeof(census));

	int i = 0, j;
	while (fread(c + i, sizeof(census), 1, fp)) {
		i++;
	}
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if (strcmp((c + i)->name, (c + j)->name) > 0) {
				temp = *(c + i);
				*(c + i) = *(c + j);
				*(c + j) = temp;
			}
		}
	}

	printf("\n");

	printf("sorted Data\n");
	for (int i = 0; i < n; i++) {
		printf("%s %d  %f\n", (c + i)->name, (c + i)->pop, (c + i)->litlvl);
	}

	free(c);
	fclose(fp);
}

void sortlvl(census temp) {
	census *c;

	FILE *fp = fopen("census.txt", "r");

	if (fp == NULL) {
		printf("Error");
		exit(0);
	}

	int n = count();
	c = (census*) malloc(n * sizeof(census));

	int i = 0, j;

	while (fread(c + i, sizeof(census), 1, fp)) {
		i++;
	}

	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if ((c + i)->litlvl > (c + j)->litlvl) {
				temp = *(c + i);
				*(c + i) = *(c + j);
				*(c + j) = temp;
			}
		}
	}

	printf("\n");

	printf("sorted Data\n");

	for (i = 0; i < n; i++) {
		printf("%s %d  %f\n", (c + i)->name, (c + i)->pop, (c + i)->litlvl);
	}

	free(c);
	fclose(fp);
}
