/*
 * fseek.c
 *
 *  Created on: 9 Apr 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	FILE *fp=NULL;

	fp=fopen("abc.txt","r");

	if(fp==NULL){
		printf("File cann't open\n");
	}

	char ch;
	fseek(fp,6,0);

	ch=fgetc(fp);
	printf("%c\n",ch);

	fseek(fp,-3,1);

	ch=fgetc(fp);
	printf("%c",ch);

	fclose(fp);
}

