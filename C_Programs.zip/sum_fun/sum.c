/*
 * sum.c
 *
 *  Created on: 10 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int sum(int,int);

int main()
{
	int a,b;
	printf("Enter a and b here:");
	scanf("%d  %d",&a,&b);

	printf("Sum is=%d\n",sum(a,b));
	return 0;
}

int sum(int a,int b){
	return  a+b;
}
