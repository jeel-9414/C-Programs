/*
 * v1.c
 *
 *  Created on: 26 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int main()
{
	char s[50];

	printf("enter string:");
	gets(s);
	int i=0,cv=0,cc=0;
	while(s[i]!='\0')
	{
		if(s[i]=='A'||s[i]=='E'||s[i]=='I'||s[i]=='O'||s[i]=='U'||s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u')
		{
			cv++;
		}else{
			cc++;
		}
		i++;
	}

	printf("v=%d c=%d",cv,cc);
}

